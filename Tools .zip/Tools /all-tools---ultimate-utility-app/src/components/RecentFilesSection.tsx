import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  FileText,
  FileImage,
  FileArchive,
  FileSpreadsheet,
  Clock,
  Trash2,
  ChevronRight,
  FolderOpen,
  CheckCircle,
} from 'lucide-react';
import { RecentProcessedFile } from '../types';

export const RecentFilesSection: React.FC = () => {
  const { recentFiles, clearRecentFiles, openTool, t } = useApp();
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);

  if (!recentFiles || recentFiles.length === 0) {
    return null;
  }

  // Format relative timestamp
  const formatTimeAgo = (timestamp: number) => {
    const elapsedMs = Date.now() - timestamp;
    const elapsedMinutes = Math.floor(elapsedMs / (1000 * 60));
    if (elapsedMinutes < 1) return 'Just now';
    if (elapsedMinutes < 60) return `${elapsedMinutes}m ago`;
    const elapsedHours = Math.floor(elapsedMinutes / 60);
    if (elapsedHours < 24) return `${elapsedHours}h ago`;
    const elapsedDays = Math.floor(elapsedHours / 24);
    if (elapsedDays === 1) return 'Yesterday';
    return `${elapsedDays}d ago`;
  };

  // Determine badge styling and icon based on file extension
  const getFileBadge = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (ext === 'pdf') {
      return {
        label: 'PDF',
        bgColor: 'bg-red-50 dark:bg-red-950/40',
        textColor: 'text-red-600 dark:text-red-400',
        borderColor: 'border-red-200 dark:border-red-900/50',
        icon: FileText,
      };
    }
    if (['jpg', 'jpeg', 'png', 'webp', 'svg'].includes(ext)) {
      return {
        label: ext.toUpperCase(),
        bgColor: 'bg-blue-50 dark:bg-blue-950/40',
        textColor: 'text-blue-600 dark:text-blue-400',
        borderColor: 'border-blue-200 dark:border-blue-900/50',
        icon: FileImage,
      };
    }
    if (['zip', 'rar', 'tar', 'gz', '7z'].includes(ext)) {
      return {
        label: 'ZIP',
        bgColor: 'bg-amber-50 dark:bg-amber-950/40',
        textColor: 'text-amber-600 dark:text-amber-400',
        borderColor: 'border-amber-200 dark:border-amber-900/50',
        icon: FileArchive,
      };
    }
    if (['xls', 'xlsx', 'csv'].includes(ext)) {
      return {
        label: ext.toUpperCase(),
        bgColor: 'bg-emerald-50 dark:bg-emerald-950/40',
        textColor: 'text-emerald-600 dark:text-emerald-400',
        borderColor: 'border-emerald-200 dark:border-emerald-900/50',
        icon: FileSpreadsheet,
      };
    }
    return {
      label: ext.toUpperCase() || 'FILE',
      bgColor: 'bg-orange-50 dark:bg-orange-950/40',
      textColor: 'text-[#FF6B00] dark:text-orange-400',
      borderColor: 'border-orange-200 dark:border-orange-900/50',
      icon: FileText,
    };
  };

  const handleCardClick = (item: RecentProcessedFile) => {
    if (item.toolId) {
      openTool(item.toolId);
    }
  };

  return (
    <div className="px-4">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-5 h-5 rounded-lg bg-orange-100 dark:bg-orange-950/60 flex items-center justify-center text-[#FF6B00]">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
            {t('recentFiles')}
          </h2>
          <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950/80 text-[#FF6B00] dark:text-orange-400">
            {recentFiles.length}
          </span>
        </div>

        {/* Clear recent files button */}
        {!showClearConfirm ? (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="text-[11px] text-neutral-400 hover:text-red-500 transition-colors flex items-center gap-1 py-0.5 px-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30"
            title={t('clearRecentFiles')}
          >
            <Trash2 className="w-3 h-3" />
            <span>Clear</span>
          </button>
        ) : (
          <div className="flex items-center gap-1 text-[11px]">
            <button
              onClick={() => {
                clearRecentFiles();
                setShowClearConfirm(false);
              }}
              className="text-red-600 font-bold hover:underline"
            >
              Confirm
            </button>
            <span className="text-neutral-300">|</span>
            <button
              onClick={() => setShowClearConfirm(false)}
              className="text-neutral-500 hover:underline"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {/* Recent Files Horizontal Scroll / Carousel */}
      <div className="flex gap-2.5 overflow-x-auto pb-2 pt-0.5 hide-scrollbar -mx-4 px-4 scroll-smooth">
        {recentFiles.map((item) => {
          const badge = getFileBadge(item.fileName);
          const IconComp = badge.icon;

          return (
            <div
              key={item.id}
              onClick={() => handleCardClick(item)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && handleCardClick(item)}
              className="group flex-shrink-0 w-64 p-3 bg-white dark:bg-[#1E1F24] rounded-2xl border border-orange-100/80 dark:border-neutral-800 shadow-sm hover:shadow-md hover:border-orange-300 dark:hover:border-orange-500/40 transition-all cursor-pointer text-left relative overflow-hidden"
            >
              {/* Top Row: Type Badge + Time */}
              <div className="flex items-center justify-between mb-2">
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${badge.bgColor} ${badge.textColor} ${badge.borderColor}`}
                >
                  <IconComp className="w-3 h-3" />
                  <span>{badge.label}</span>
                </span>
                <span className="text-[10px] text-neutral-400 font-medium">
                  {formatTimeAgo(item.timestamp)}
                </span>
              </div>

              {/* File Name */}
              <div
                className="text-xs font-bold text-neutral-800 dark:text-neutral-100 truncate group-hover:text-[#FF6B00] transition-colors"
                title={item.fileName}
              >
                {item.fileName}
              </div>

              {/* Action / Tool Summary */}
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate mt-0.5">
                {item.actionSummary || item.toolName}
              </div>

              {/* Footer info: size and tool trigger */}
              <div className="mt-2.5 pt-2 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-[10px] text-neutral-400">
                <span className="truncate max-w-[130px]">
                  {item.toolName}
                  {item.sizeKb ? ` • ${item.sizeKb} KB` : ''}
                </span>
                <span className="inline-flex items-center gap-0.5 font-semibold text-[#FF6B00] group-hover:translate-x-0.5 transition-transform">
                  <span>Open</span>
                  <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
