import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import JSZip from 'jszip';
import confetti from 'canvas-confetti';
import {
  FolderArchive,
  FolderOpen,
  Table,
  PencilLine,
  Info,
  Upload,
  Download,
  FileText,
  CheckCircle2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface FileToolsProps {
  toolId: string;
}

export const FileTools: React.FC<FileToolsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();
  const [files, setFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultFileName, setResultFileName] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // ZIP Extractor state
  const [zipEntries, setZipEntries] = useState<{ name: string; size: number; blob: Blob }[]>([]);

  // CSV Converter state
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<string[][]>([]);
  const [jsonOutput, setJsonOutput] = useState<string>('');

  // Batch Renamer state
  const [renamePrefix, setRenamePrefix] = useState<string>('Doc_');
  const [renameStartIndex, setRenameStartIndex] = useState<number>(1);
  const [renamedList, setRenamedList] = useState<{ oldName: string; newName: string; file: File }[]>([]);

  // File Inspector details
  const [inspectedFile, setInspectedFile] = useState<{
    name: string;
    size: number;
    type: string;
    lastModified: string;
  } | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const selected = Array.from(e.target.files);
    setFiles(selected);
    setResultUrl(null);
    setError(null);

    // 1. If File Inspector
    if (toolId === 'file-size-checker') {
      const f = selected[0];
      setInspectedFile({
        name: f.name,
        size: f.size,
        type: f.type || 'Unknown MIME / Extension: ' + f.name.split('.').pop(),
        lastModified: new Date(f.lastModified).toLocaleString(),
      });
      addToHistory(toolId, `Inspected ${f.name} (${(f.size / 1024).toFixed(1)} KB)`);
    }

    // 2. If CSV Converter
    else if (toolId === 'file-csv-converter') {
      const f = selected[0];
      const text = await f.text();
      const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
      if (lines.length > 0) {
        const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
        const rows = lines.slice(1, 20).map((line) => line.split(',').map((c) => c.trim().replace(/^"|"$/g, '')));
        setCsvHeaders(headers);
        setCsvRows(rows);

        // Convert to JSON
        const jsonList = lines.slice(1).map((line) => {
          const cells = line.split(',');
          const obj: Record<string, string> = {};
          headers.forEach((h, idx) => {
            obj[h] = (cells[idx] || '').trim().replace(/^"|"$/g, '');
          });
          return obj;
        });
        setJsonOutput(JSON.stringify(jsonList, null, 2));
      }
    }

    // 3. If Batch Renamer
    else if (toolId === 'file-renamer') {
      updateRenamedPreview(selected, renamePrefix, renameStartIndex);
    }
  };

  const updateRenamedPreview = (fileList: File[], prefix: string, start: number) => {
    const list = fileList.map((f, idx) => {
      const ext = f.name.includes('.') ? '.' + f.name.split('.').pop() : '';
      const num = String(start + idx).padStart(2, '0');
      return {
        oldName: f.name,
        newName: `${prefix}${num}${ext}`,
        file: f,
      };
    });
    setRenamedList(list);
  };

  // ZIP Creator Engine
  const createZip = async () => {
    try {
      setProcessing(true);
      setError(null);

      const zip = new JSZip();
      files.forEach((f) => {
        zip.file(f.name, f);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      setResultUrl(url);
      const name = `Archive_Bundle_${Date.now()}.zip`;
      setResultFileName(name);
      addToHistory(toolId, `Created ZIP with ${files.length} files`, name);
      confetti({ particleCount: 50, spread: 60 });
    } catch (err: any) {
      setError(err.message || 'Failed to create ZIP');
    } finally {
      setProcessing(false);
    }
  };

  // ZIP Extractor Engine
  const extractZip = async () => {
    try {
      setProcessing(true);
      setError(null);
      if (files.length === 0) throw new Error('Please select a ZIP file.');

      const file = files[0];
      const zip = new JSZip();
      const loaded = await zip.loadAsync(file);

      const entries: { name: string; size: number; blob: Blob }[] = [];
      const entryPromises: Promise<void>[] = [];

      loaded.forEach((relativePath, zipEntry) => {
        if (!zipEntry.dir) {
          const p = zipEntry.async('blob').then((b) => {
            entries.push({
              name: relativePath,
              size: b.size,
              blob: b,
            });
          });
          entryPromises.push(p);
        }
      });

      await Promise.all(entryPromises);
      setZipEntries(entries);
      addToHistory(toolId, `Extracted ${entries.length} files from ${file.name}`);
      confetti({ particleCount: 40, spread: 50 });
    } catch (err: any) {
      setError(err.message || 'Failed to extract ZIP file.');
    } finally {
      setProcessing(false);
    }
  };

  // Download all renamed files bundled as ZIP
  const downloadRenamedZip = async () => {
    try {
      setProcessing(true);
      const zip = new JSZip();
      renamedList.forEach((item) => {
        zip.file(item.newName, item.file);
      });
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Renamed_Files_${Date.now()}.zip`;
      a.click();
      addToHistory(toolId, `Renamed & downloaded ${renamedList.length} files`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleClear = () => {
    setFiles([]);
    setResultUrl(null);
    setZipEntries([]);
    setCsvHeaders([]);
    setCsvRows([]);
    setJsonOutput('');
    setRenamedList([]);
    setInspectedFile(null);
    setError(null);
  };

  return (
    <div className="space-y-4">
      {/* Upload Zone */}
      {!resultUrl && zipEntries.length === 0 && !inspectedFile && csvHeaders.length === 0 && renamedList.length === 0 && (
        <div className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors">
          <input
            type="file"
            multiple={toolId === 'file-zip-create' || toolId === 'file-renamer'}
            accept={toolId === 'file-zip-extract' ? '.zip' : toolId === 'file-csv-converter' ? '.csv,.tsv,.txt' : '*/*'}
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm">
            <Upload className="w-6 h-6 stroke-[2]" />
          </div>
          <h3 className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
            {t('dropFiles')}
          </h3>
          <p className="text-[11px] text-neutral-500 mt-1">
            {toolId === 'file-zip-create'
              ? 'Select multiple files to compress into a ZIP archive'
              : toolId === 'file-zip-extract'
              ? 'Upload .zip file to unpack and view files'
              : toolId === 'file-csv-converter'
              ? 'Upload .csv file to view table & export JSON'
              : toolId === 'file-renamer'
              ? 'Select files to rename in batch'
              : 'Inspect any file details and size'}
          </p>
        </div>
      )}

      {/* 1. ZIP Creator Action */}
      {toolId === 'file-zip-create' && files.length > 0 && !resultUrl && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
            <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
              Files to Archive ({files.length})
            </span>
            <button onClick={handleClear} className="text-[11px] text-red-500 font-bold hover:underline">
              Clear
            </button>
          </div>
          <div className="max-h-36 overflow-y-auto space-y-1 text-xs">
            {files.map((f, i) => (
              <div key={i} className="flex justify-between py-1">
                <span className="truncate text-neutral-700 dark:text-neutral-300">{f.name}</span>
                <span className="text-[10px] text-neutral-400">{(f.size / 1024).toFixed(0)} KB</span>
              </div>
            ))}
          </div>

          <button
            onClick={createZip}
            disabled={processing}
            className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2"
          >
            {processing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FolderArchive className="w-4 h-4" />}
            <span>Compress to ZIP Archive</span>
          </button>
        </div>
      )}

      {/* 2. ZIP Extractor View */}
      {toolId === 'file-zip-extract' && zipEntries.length > 0 && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-5 space-y-3 shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
            <span className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
              Files Extracted from ZIP ({zipEntries.length})
            </span>
            <button onClick={handleClear} className="text-[11px] text-red-500 font-bold">
              Close
            </button>
          </div>
          <div className="max-h-60 overflow-y-auto space-y-2">
            {zipEntries.map((item, i) => (
              <div key={i} className="flex items-center justify-between p-2.5 bg-neutral-50 dark:bg-neutral-900 rounded-xl text-xs">
                <div className="truncate mr-2">
                  <p className="font-bold text-neutral-800 dark:text-neutral-200 truncate">{item.name}</p>
                  <p className="text-[10px] text-neutral-400">{(item.size / 1024).toFixed(1)} KB</p>
                </div>
                <button
                  onClick={() => {
                    const url = URL.createObjectURL(item.blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = item.name.split('/').pop() || 'file';
                    a.click();
                  }}
                  className="px-2.5 py-1 bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] font-bold text-[11px] rounded-lg shrink-0 flex items-center gap-1"
                >
                  <Download className="w-3 h-3" />
                  <span>Save</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. CSV Converter View */}
      {toolId === 'file-csv-converter' && csvHeaders.length > 0 && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 space-y-3 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
              CSV Table Preview (First 20 rows)
            </span>
            <button onClick={handleClear} className="text-[11px] text-red-500 font-bold">
              Clear
            </button>
          </div>
          <div className="overflow-x-auto border border-neutral-200 dark:border-neutral-700 rounded-xl max-h-56">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-orange-50 dark:bg-neutral-800 text-[#FF6B00] font-bold">
                <tr>
                  {csvHeaders.map((h, i) => (
                    <th key={i} className="p-2 border-b border-neutral-200 dark:border-neutral-700 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {csvRows.map((row, r) => (
                  <tr key={r} className="border-b border-neutral-100 dark:border-neutral-800">
                    {row.map((cell, c) => (
                      <td key={c} className="p-2 whitespace-nowrap text-neutral-700 dark:text-neutral-300 text-[11px]">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                const blob = new Blob([jsonOutput], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `CSV_Converted_${Date.now()}.json`;
                a.click();
              }}
              className="w-full py-2.5 bg-[#FF6B00] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON Data</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. Batch Renamer View */}
      {toolId === 'file-renamer' && renamedList.length > 0 && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 space-y-3 shadow-sm">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="font-bold text-neutral-600 block mb-1">Prefix</label>
              <input
                type="text"
                value={renamePrefix}
                onChange={(e) => {
                  setRenamePrefix(e.target.value);
                  updateRenamedPreview(files, e.target.value, renameStartIndex);
                }}
                className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded-xl"
              />
            </div>
            <div>
              <label className="font-bold text-neutral-600 block mb-1">Start Number</label>
              <input
                type="number"
                value={renameStartIndex}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10) || 1;
                  setRenameStartIndex(val);
                  updateRenamedPreview(files, renamePrefix, val);
                }}
                className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded-xl"
              />
            </div>
          </div>

          <div className="max-h-40 overflow-y-auto space-y-1 text-xs">
            {renamedList.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-neutral-50 dark:bg-neutral-900 rounded-xl">
                <span className="text-neutral-400 truncate max-w-[120px] line-through">{item.oldName}</span>
                <span className="font-bold text-[#FF6B00] truncate max-w-[140px]">➔ {item.newName}</span>
              </div>
            ))}
          </div>

          <button
            onClick={downloadRenamedZip}
            disabled={processing}
            className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Download All Renamed Files (ZIP)</span>
          </button>
        </div>
      )}

      {/* 5. File Size & Inspector View */}
      {toolId === 'file-size-checker' && inspectedFile && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#FF6B00]">
            <Info className="w-4 h-4" />
            <span>File Inspection Report</span>
          </div>
          <div className="space-y-2 text-xs divide-y divide-neutral-100 dark:divide-neutral-800">
            <div className="flex justify-between py-1.5">
              <span className="text-neutral-500">File Name:</span>
              <span className="font-bold text-neutral-800 dark:text-neutral-200 truncate max-w-[180px]">
                {inspectedFile.name}
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-neutral-500">Exact Size:</span>
              <span className="font-bold text-[#FF6B00]">
                {(inspectedFile.size / 1024).toFixed(2)} KB ({inspectedFile.size.toLocaleString()} bytes)
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-neutral-500">MIME / Type:</span>
              <span className="font-mono text-neutral-700 dark:text-neutral-300">
                {inspectedFile.type}
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-neutral-500">Last Modified:</span>
              <span className="text-neutral-700 dark:text-neutral-300">
                {inspectedFile.lastModified}
              </span>
            </div>
          </div>

          <button
            onClick={handleClear}
            className="w-full py-2.5 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-xl"
          >
            Inspect Another File
          </button>
        </div>
      )}

      {/* Download Result View */}
      {resultUrl && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm animate-scale-up">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
          </div>
          <h3 className="font-extrabold text-base text-neutral-900 dark:text-neutral-100">
            {t('success')}
          </h3>
          <p className="text-xs text-neutral-500 font-mono truncate max-w-xs mx-auto">
            {resultFileName}
          </p>

          <a
            href={resultUrl}
            download={resultFileName}
            className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{t('downloadResult')}</span>
          </a>
        </div>
      )}
    </div>
  );
};
