# ALL TOOLS – Android Project & APK Build Guide

> **Brand Name:** ALL TOOLS  
> **Tagline:** One App – All Useful Tools in Your Pocket  
> **Theme:** Orange & White Modern Google-Style & CSC Digital Utility Portal  
> **Package Name:** `com.alltools.utility`

This package contains the complete, production-ready source code for **ALL TOOLS**, structured to open directly in **Android Studio** or be built via the command line with Gradle.

---

## 📁 Project Structure

```
├── android/                         # Complete Android Studio project
│   ├── app/
│   │   ├── build.gradle             # Application build configuration
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml  # Android permissions (Camera, File Storage, Internet)
│   │   │   ├── java/com/alltools/utility/MainActivity.java # WebView host with Camera & File Chooser
│   │   │   ├── res/                 # App resources (Colors, Styles, Strings, FileProvider)
│   │   │   └── assets/www/          # Pre-built, 100% offline standalone web app bundle
│   ├── build.gradle                 # Project-level Gradle build script
│   ├── settings.gradle              # Module includes (:app)
│   └── gradle.properties            # JVM & AndroidX optimization settings
├── src/                             # Complete React 19 + TypeScript source code
│   ├── components/                  # Tool engines, UI cards, modals, navigation
│   ├── context/                     # AppContext with language, favorites & history
│   ├── data/                        # Catalog of 40+ utility tools
│   ├── translations/                # English, Hindi (हिन्दी), Marathi (मराठी)
│   └── types/                       # TypeScript interfaces
├── dist/                            # Production build output
├── index.html                       # App entry point
├── package.json                     # Dependencies & build scripts
├── vite.config.ts                   # Vite bundler configuration
└── server.ts                        # Full-stack Node.js / Express server with Gemini OCR
```

---

## 🚀 How to Build Android APK (Step-by-Step)

### Prerequisites
1. **Android Studio** (Hedgehog, Iguana, Jellyfish, or newer). Download from [developer.android.com/studio](https://developer.android.com/studio).
2. **Java Development Kit (JDK 17 or higher)** (included with Android Studio).
3. **Android SDK** with API 34 installed (configured automatically by Android Studio).

---

### Method 1: Using Android Studio (Recommended & Easiest)

1. **Extract the ZIP file** to a folder on your computer.
2. Launch **Android Studio**.
3. Click **Open** (or `File > Open...`).
4. Navigate into the extracted folder and select the `android` directory (the one containing `build.gradle` and `settings.gradle`), then click **OK**.
5. Wait for Gradle sync to complete (Android Studio will automatically download any necessary dependencies).
6. In the top menu, go to:
   ```
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   ```
7. Once the build finishes (usually 30–60 seconds), Android Studio will show a popup at the bottom right:
   ```
   APK(s) generated successfully for 1 module: Locate
   ```
8. Click **Locate**. This will open the folder containing your generated APK:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

### Method 2: Building via Terminal / Command Line

You can build the APK directly without opening the Android Studio GUI:

1. Open your terminal or Command Prompt.
2. Navigate into the `android` folder:
   ```bash
   cd android
   ```
3. Run the Gradle build command:
   - **On Windows:**
     ```cmd
     gradlew.bat assembleDebug
     ```
   - **On macOS / Linux:**
     ```bash
     chmod +x gradlew
     ./gradlew assembleDebug
     ```
4. Your compiled APK file will be located at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 📲 Installing the APK on Your Android Device

### Option A: Direct Transfer (Simplest)
1. Send `app-debug.apk` to your phone via:
   - WhatsApp, Telegram, or Gmail attachment
   - Google Drive or USB file transfer
2. On your phone, tap the file and select **Install**.
3. If prompted with *"Install unknown apps"*, allow permission for your browser or file manager and proceed.

### Option B: Using ADB (Android Debug Bridge)
1. Connect your phone via USB with **USB Debugging** enabled in Developer Options.
2. Run:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 🛠️ Making Changes to the Web Source Code

If you edit any files in `src/` (e.g., adding a new tool, changing translations or colors):

1. Install web dependencies (if not already installed):
   ```bash
   npm install
   ```
2. Build the updated web bundle:
   ```bash
   npm run build
   ```
3. Sync the updated build to the Android assets directory:
   - **On Windows:**
     ```cmd
     xcopy /E /I /Y dist android\app\src\main\assets\www
     ```
   - **On macOS / Linux:**
     ```bash
     cp -r dist/* android/app/src/main/assets/www/
     ```
4. Rebuild the APK in Android Studio (`Build > Build APK(s)`).

---

## 🔐 Permissions Configured in AndroidManifest.xml

| Permission | Purpose |
|------------|---------|
| `CAMERA` | Document scanner, Camera capture for receipts & Aadhaar/PAN cards |
| `READ_MEDIA_IMAGES` / `READ_EXTERNAL_STORAGE` | Selecting photos, PDFs, and files for processing |
| `INTERNET` | Multilingual AI OCR (Gemini API) and official CSC portal link navigation |

---

## 🌟 Application Capabilities Included
- **100% Offline Capable:** The built web app runs locally on the phone inside the WebView.
- **Hardware Back Button Handling:** Supports seamless back navigation without accidentally closing the app.
- **Native File Chooser:** Supports camera photo snapping and device file browsing seamlessly.
- **Deep-linking & External Intents:** Supports direct UPI payments (`upi://`), WhatsApp messaging (`whatsapp://`), telephone (`tel:`), and email (`mailto:`).
