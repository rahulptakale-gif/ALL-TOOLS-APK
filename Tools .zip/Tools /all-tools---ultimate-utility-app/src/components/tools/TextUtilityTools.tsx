import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  NotebookPen,
  CaseSensitive,
  Binary,
  KeyRound,
  Palette,
  Copy,
  Check,
  Download,
  Trash2,
  RefreshCw,
  Upload,
} from 'lucide-react';

interface TextUtilityToolsProps {
  toolId: string;
}

export const TextUtilityTools: React.FC<TextUtilityToolsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();

  // --- Notepad State ---
  const [noteContent, setNoteContent] = useState<string>(() => {
    return localStorage.getItem('alltools_notepad_draft') || 'Customer Notes / Token Details:\n- Name:\n- Mobile:\n- Service: Aadhaar PVC Card Print\n- Fee: ₹50 Paid';
  });
  const [copiedNote, setCopiedNote] = useState(false);

  useEffect(() => {
    localStorage.setItem('alltools_notepad_draft', noteContent);
  }, [noteContent]);

  // --- Text Case Converter State ---
  const [inputText, setInputText] = useState<string>('all tools ultimate mobile utility app for digital seva');

  // --- Password Generator State ---
  const [passLength, setPassLength] = useState<number>(14);
  const [includeUpper, setIncludeUpper] = useState<boolean>(true);
  const [includeLower, setIncludeLower] = useState<boolean>(true);
  const [includeNumbers, setIncludeNumbers] = useState<boolean>(true);
  const [includeSymbols, setIncludeSymbols] = useState<boolean>(true);
  const [generatedPass, setGeneratedPass] = useState<string>('');
  const [copiedPass, setCopiedPass] = useState(false);

  const generatePassword = () => {
    let chars = '';
    if (includeUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeLower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

    let result = '';
    const array = new Uint32Array(passLength);
    crypto.getRandomValues(array);
    for (let i = 0; i < passLength; i++) {
      result += chars[array[i] % chars.length];
    }
    setGeneratedPass(result);
  };

  useEffect(() => {
    generatePassword();
  }, [passLength, includeUpper, includeLower, includeNumbers, includeSymbols]);

  // --- Image Color Picker State ---
  const [pickerImage, setPickerImage] = useState<string | null>(null);
  const [pickedColor, setPickedColor] = useState<{ hex: string; rgb: string; hsl: string } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const handleColorPick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) * (canvas.width / rect.width));
    const y = Math.floor((e.clientY - rect.top) * (canvas.height / rect.height));

    const pixel = ctx.getImageData(x, y, 1, 1).data;
    const r = pixel[0];
    const g = pixel[1];
    const b = pixel[2];

    const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}`;
    const rgbStr = `rgb(${r}, ${g}, ${b})`;

    // Convert RGB to HSL
    const rNorm = r / 255;
    const gNorm = g / 255;
    const bNorm = b / 255;
    const max = Math.max(rNorm, gNorm, bNorm);
    const min = Math.min(rNorm, gNorm, bNorm);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case rNorm: h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0); break;
        case gNorm: h = (bNorm - rNorm) / d + 2; break;
        case bNorm: h = (rNorm - gNorm) / d + 4; break;
      }
      h /= 6;
    }
    const hslStr = `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;

    setPickedColor({ hex, rgb: rgbStr, hsl: hslStr });
  };

  const handlePickerImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      setPickerImage(url);
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
      };
      img.src = url;
    }
  };

  // Text Case transformations
  const toUppercase = () => setInputText(inputText.toUpperCase());
  const toLowercase = () => setInputText(inputText.toLowerCase());
  const toTitleCase = () => {
    setInputText(
      inputText
        .toLowerCase()
        .split(' ')
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ')
    );
  };
  const toSentenceCase = () => {
    setInputText(
      inputText
        .toLowerCase()
        .replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase())
    );
  };
  const toCamelCase = () => {
    setInputText(
      inputText
        .toLowerCase()
        .replace(/[^a-zA-Z0-9]+(.)/g, (_m, chr) => chr.toUpperCase())
    );
  };
  const toSnakeCase = () => {
    setInputText(
      inputText
        .trim()
        .toLowerCase()
        .replace(/[\s\W-]+/g, '_')
    );
  };

  // Word Counter calculations
  const trimmed = inputText.trim();
  const wordCount = trimmed ? trimmed.split(/\s+/).length : 0;
  const charWithSpaces = inputText.length;
  const charNoSpaces = inputText.replace(/\s/g, '').length;
  const lineCount = inputText ? inputText.split('\n').length : 0;
  const readingTimeMins = Math.ceil(wordCount / 200);

  return (
    <div className="space-y-4">
      {/* 1. Quick Notepad */}
      {toolId === 'text-notepad' && (
        <div className="space-y-3">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 shadow-sm space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                Auto-saved in browser storage
              </span>
              <button
                onClick={() => setNoteContent('')}
                className="text-neutral-400 hover:text-red-500 p-1"
                title="Clear Note"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <textarea
              rows={8}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="Type your notes, customer order details or draft text here..."
              className="w-full bg-transparent border-0 focus:ring-0 text-xs sm:text-sm text-neutral-800 dark:text-neutral-100 resize-none font-sans leading-relaxed"
            />
            <div className="text-[10px] text-neutral-400 pt-1 border-t border-neutral-100 dark:border-neutral-800 flex justify-between">
              <span>{noteContent.trim() ? noteContent.trim().split(/\s+/).length : 0} words</span>
              <span>{noteContent.length} characters</span>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(noteContent);
                setCopiedNote(true);
                setTimeout(() => setCopiedNote(false), 2000);
              }}
              className="flex-1 py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
            >
              {copiedNote ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedNote ? 'Copied' : 'Copy All Text'}</span>
            </button>
            <button
              onClick={() => {
                const blob = new Blob([noteContent], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `Notes_${Date.now()}.txt`;
                a.click();
              }}
              className="px-4 py-3 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-xl flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Export TXT</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Text Case Converter */}
      {toolId === 'text-case-converter' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 space-y-3 shadow-sm">
            <textarea
              rows={4}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste or enter text here..."
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl text-xs"
            />
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                onClick={toUppercase}
                className="py-2 px-1 bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] font-bold rounded-xl border border-orange-200 dark:border-orange-900"
              >
                UPPERCASE
              </button>
              <button
                onClick={toLowercase}
                className="py-2 px-1 bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] font-bold rounded-xl border border-orange-200 dark:border-orange-900"
              >
                lowercase
              </button>
              <button
                onClick={toTitleCase}
                className="py-2 px-1 bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] font-bold rounded-xl border border-orange-200 dark:border-orange-900"
              >
                Title Case
              </button>
              <button
                onClick={toSentenceCase}
                className="py-2 px-1 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-semibold rounded-xl"
              >
                Sentence case
              </button>
              <button
                onClick={toCamelCase}
                className="py-2 px-1 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-semibold rounded-xl"
              >
                camelCase
              </button>
              <button
                onClick={toSnakeCase}
                className="py-2 px-1 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-semibold rounded-xl"
              >
                snake_case
              </button>
            </div>
          </div>

          <button
            onClick={() => {
              navigator.clipboard.writeText(inputText);
              alert('Copied converted text!');
            }}
            className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
          >
            <Copy className="w-4 h-4" />
            <span>Copy Converted Text</span>
          </button>
        </div>
      )}

      {/* 3. Word & Character Counter */}
      {toolId === 'text-counter' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 shadow-sm">
            <textarea
              rows={4}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste text here to count words, characters, and reading time..."
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 p-3.5 rounded-2xl text-center shadow-sm">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">Total Words</span>
              <div className="text-2xl font-black text-[#FF6B00] mt-0.5">{wordCount}</div>
            </div>
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 p-3.5 rounded-2xl text-center shadow-sm">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">Characters</span>
              <div className="text-2xl font-black text-neutral-800 dark:text-neutral-100 mt-0.5">
                {charWithSpaces}
              </div>
            </div>
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 p-3.5 rounded-2xl text-center shadow-sm">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">Without Spaces</span>
              <div className="text-xl font-bold text-neutral-700 dark:text-neutral-300 mt-0.5">
                {charNoSpaces}
              </div>
            </div>
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 p-3.5 rounded-2xl text-center shadow-sm">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">Reading Time</span>
              <div className="text-xl font-bold text-neutral-700 dark:text-neutral-300 mt-0.5">
                ~{readingTimeMins} min
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Password Generator */}
      {toolId === 'text-password-gen' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="p-3.5 bg-neutral-900 text-white rounded-2xl flex items-center justify-between font-mono text-sm tracking-wider break-all">
              <span>{generatedPass}</span>
              <button
                onClick={generatePassword}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
                title="Regenerate"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>Length</span>
                  <span className="text-[#FF6B00] font-bold">{passLength}</span>
                </div>
                <input
                  type="range"
                  min="6"
                  max="32"
                  value={passLength}
                  onChange={(e) => setPassLength(parseInt(e.target.value, 10))}
                  className="w-full accent-[#FF6B00]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeUpper}
                    onChange={(e) => setIncludeUpper(e.target.checked)}
                    className="accent-[#FF6B00]"
                  />
                  <span>Uppercase (A-Z)</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeLower}
                    onChange={(e) => setIncludeLower(e.target.checked)}
                    className="accent-[#FF6B00]"
                  />
                  <span>Lowercase (a-z)</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeNumbers}
                    onChange={(e) => setIncludeNumbers(e.target.checked)}
                    className="accent-[#FF6B00]"
                  />
                  <span>Numbers (0-9)</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={includeSymbols}
                    onChange={(e) => setIncludeSymbols(e.target.checked)}
                    className="accent-[#FF6B00]"
                  />
                  <span>Symbols (!@#$)</span>
                </label>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              navigator.clipboard.writeText(generatedPass);
              setCopiedPass(true);
              setTimeout(() => setCopiedPass(false), 2000);
            }}
            className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
          >
            {copiedPass ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copiedPass ? 'Password Copied' : 'Copy Password'}</span>
          </button>
        </div>
      )}

      {/* 5. Image Color Picker */}
      {toolId === 'text-color-picker' && (
        <div className="space-y-4">
          {!pickerImage && (
            <div className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors">
              <input
                type="file"
                accept="image/*"
                onChange={handlePickerImageUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm">
                <Palette className="w-6 h-6 stroke-[2]" />
              </div>
              <h3 className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
                Upload Image to Pick Colors
              </h3>
              <p className="text-[11px] text-neutral-500 mt-1">
                Click anywhere on the image canvas to get HEX, RGB & HSL
              </p>
            </div>
          )}

          {pickerImage && (
            <div className="space-y-3">
              <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-3 shadow-sm overflow-hidden text-center">
                <p className="text-[11px] text-neutral-400 mb-2">Tap/Click on image to inspect color</p>
                <div className="max-h-64 overflow-auto rounded-xl border border-neutral-200 dark:border-neutral-700">
                  <canvas
                    ref={canvasRef}
                    onClick={handleColorPick}
                    className="max-w-full cursor-crosshair mx-auto"
                  />
                </div>
              </div>

              {pickedColor && (
                <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-4 shadow-sm flex items-center gap-4">
                  <div
                    style={{ backgroundColor: pickedColor.hex }}
                    className="w-14 h-14 rounded-2xl shadow-inner border border-black/10 shrink-0"
                  />
                  <div className="min-w-0 flex-1 space-y-1 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-mono font-bold text-neutral-900 dark:text-neutral-100 text-sm">
                        {pickedColor.hex}
                      </span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(pickedColor.hex);
                          alert(`Copied ${pickedColor.hex}`);
                        }}
                        className="text-[#FF6B00] font-bold text-[11px] hover:underline"
                      >
                        Copy HEX
                      </button>
                    </div>
                    <p className="font-mono text-[11px] text-neutral-500">{pickedColor.rgb}</p>
                    <p className="font-mono text-[10px] text-neutral-400">{pickedColor.hsl}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
