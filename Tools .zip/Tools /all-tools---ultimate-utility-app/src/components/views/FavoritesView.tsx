import React from 'react';
import { useApp } from '../../context/AppContext';
import { ALL_TOOLS_LIST } from '../../data/tools';
import { ToolCard } from '../ToolCard';
import { Heart } from 'lucide-react';

export const FavoritesView: React.FC = () => {
  const { favorites, t } = useApp();

  const favoriteTools = favorites
    .map((id) => ALL_TOOLS_LIST.find((tool) => tool.id === id))
    .filter(Boolean) as typeof ALL_TOOLS_LIST;

  return (
    <div className="px-4 py-4 pb-24 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
            {t('favoriteTools')}
          </h1>
          <p className="text-xs text-neutral-500">
            {favoriteTools.length} {favoriteTools.length === 1 ? 'tool' : 'tools'} saved for instant access
          </p>
        </div>
      </div>

      {favoriteTools.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {favoriteTools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 px-4 bg-white dark:bg-[#1E1F24] rounded-3xl border border-orange-100 dark:border-neutral-800">
          <div className="w-14 h-14 rounded-2xl bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] flex items-center justify-center mx-auto mb-3">
            <Heart className="w-7 h-7 stroke-[1.5]" />
          </div>
          <h3 className="font-bold text-sm text-neutral-800 dark:text-neutral-200">
            {t('noFavorites')}
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
            {t('noFavoritesDesc')}
          </p>
        </div>
      )}
    </div>
  );
};
