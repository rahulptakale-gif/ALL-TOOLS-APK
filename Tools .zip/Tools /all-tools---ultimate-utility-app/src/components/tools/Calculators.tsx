import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  Clock,
  Receipt,
  BadgePercent,
  Percent,
  Calculator,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface CalculatorsProps {
  toolId: string;
}

export const Calculators: React.FC<CalculatorsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();

  // --- Age Calculator State ---
  const [birthDate, setBirthDate] = useState<string>('2000-01-01');
  const [targetDate, setTargetDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // --- GST Calculator State ---
  const [gstAmount, setGstAmount] = useState<number>(1000);
  const [gstRate, setGstRate] = useState<number>(18);
  const [gstMode, setGstMode] = useState<'exclusive' | 'inclusive'>('exclusive');

  // --- EMI Calculator State ---
  const [loanAmount, setLoanAmount] = useState<number>(500000);
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [loanTenureYears, setLoanTenureYears] = useState<number>(5);

  // --- Date Calculator State ---
  const [d1, setD1] = useState<string>(new Date().toISOString().split('T')[0]);
  const [d2, setD2] = useState<string>(
    new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0]
  );

  // --- Percentage State ---
  const [pctVal1, setPctVal1] = useState<number>(18);
  const [pctVal2, setPctVal2] = useState<number>(2500);

  // --- Standard Calculator State ---
  const [calcDisplay, setCalcDisplay] = useState<string>('0');
  const [calcHistory, setCalcHistory] = useState<string[]>([]);

  // 1. Calculate Age
  const computeAge = () => {
    const b = new Date(birthDate);
    const now = new Date(targetDate);
    if (isNaN(b.getTime()) || isNaN(now.getTime())) return null;

    let years = now.getFullYear() - b.getFullYear();
    let months = now.getMonth() - b.getMonth();
    let days = now.getDate() - b.getDate();

    if (days < 0) {
      months -= 1;
      const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    const totalDays = Math.floor((now.getTime() - b.getTime()) / (1000 * 60 * 60 * 24));
    const totalHours = totalDays * 24;

    // Next Birthday calculation
    let nextBday = new Date(now.getFullYear(), b.getMonth(), b.getDate());
    if (nextBday.getTime() < now.getTime()) {
      nextBday = new Date(now.getFullYear() + 1, b.getMonth(), b.getDate());
    }
    const daysToNextBday = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    return { years, months, days, totalDays, totalHours, daysToNextBday };
  };

  // 2. Compute GST
  const computeGst = () => {
    let base = gstAmount;
    let tax = 0;
    let total = 0;

    if (gstMode === 'exclusive') {
      tax = (gstAmount * gstRate) / 100;
      total = gstAmount + tax;
    } else {
      total = gstAmount;
      base = (gstAmount * 100) / (100 + gstRate);
      tax = total - base;
    }

    const cgst = tax / 2;
    const sgst = tax / 2;

    return { base, tax, cgst, sgst, total };
  };

  // 3. Compute EMI
  const computeEmi = () => {
    const P = loanAmount;
    const r = interestRate / 12 / 100;
    const n = loanTenureYears * 12;
    if (r === 0 || n === 0) return { emi: 0, totalInterest: 0, totalPayable: 0 };

    const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayable = emi * n;
    const totalInterest = totalPayable - P;

    return { emi: Math.round(emi), totalInterest: Math.round(totalInterest), totalPayable: Math.round(totalPayable) };
  };

  // 4. Compute Date Diff
  const computeDateDiff = () => {
    const dateA = new Date(d1);
    const dateB = new Date(d2);
    const diffMs = Math.abs(dateB.getTime() - dateA.getTime());
    const totalDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(totalDays / 7);
    const remDays = totalDays % 7;
    return { totalDays, weeks, remDays };
  };

  // Standard Calc input
  const handleCalcPress = (btn: string) => {
    if (btn === 'C') {
      setCalcDisplay('0');
    } else if (btn === '=') {
      try {
        const sanitized = calcDisplay.replace(/×/g, '*').replace(/÷/g, '/');
        // eslint-disable-next-line no-eval
        const result = Function(`'use strict'; return (${sanitized})`)();
        setCalcHistory((prev) => [`${calcDisplay} = ${result}`, ...prev].slice(0, 5));
        setCalcDisplay(String(result));
      } catch {
        setCalcDisplay('Error');
      }
    } else {
      if (calcDisplay === '0' || calcDisplay === 'Error') {
        setCalcDisplay(btn);
      } else {
        setCalcDisplay(calcDisplay + btn);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* 1. Age Calculator */}
      {toolId === 'calc-age' && (() => {
        const age = computeAge();
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3 shadow-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Age at Date
                  </label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>
            </div>

            {age && (
              <div className="bg-gradient-to-br from-[#FFF3E8] to-[#FFE4CC] dark:from-[#2A1706] dark:to-[#3D220A] border border-orange-200 dark:border-orange-800/60 rounded-3xl p-5 shadow-sm space-y-4">
                <div className="text-center">
                  <span className="text-[10px] font-bold text-[#FF6B00] uppercase tracking-wider block">
                    Exact Age Today
                  </span>
                  <div className="text-2xl font-black text-neutral-900 dark:text-white mt-1">
                    {age.years} <span className="text-sm font-semibold text-neutral-500">Years</span> {age.months}{' '}
                    <span className="text-sm font-semibold text-neutral-500">Months</span> {age.days}{' '}
                    <span className="text-sm font-semibold text-neutral-500">Days</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-orange-200/60 dark:border-orange-800/40">
                  <div className="bg-white/80 dark:bg-neutral-900/60 p-2.5 rounded-xl">
                    <span className="text-[10px] text-neutral-400 block font-semibold">Total Days</span>
                    <span className="font-extrabold text-sm text-neutral-800 dark:text-neutral-100">
                      {age.totalDays.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-white/80 dark:bg-neutral-900/60 p-2.5 rounded-xl">
                    <span className="text-[10px] text-neutral-400 block font-semibold">Total Hours</span>
                    <span className="font-extrabold text-sm text-neutral-800 dark:text-neutral-100">
                      {age.totalHours.toLocaleString()}
                    </span>
                  </div>
                  <div className="bg-white/80 dark:bg-neutral-900/60 p-2.5 rounded-xl">
                    <span className="text-[10px] text-neutral-400 block font-semibold">Next Birthday</span>
                    <span className="font-extrabold text-sm text-[#FF6B00]">
                      {age.daysToNextBday} days
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* 2. GST Calculator */}
      {toolId === 'calc-gst' && (() => {
        const gst = computeGst();
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3 shadow-sm">
              <div>
                <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Amount ₹ (Base or MRP)
                </label>
                <input
                  type="number"
                  value={gstAmount}
                  onChange={(e) => setGstAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1.5">
                  GST Slab
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[5, 12, 18, 28].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setGstRate(rate)}
                      className={`py-2 rounded-xl text-xs font-bold border ${
                        gstRate === rate
                          ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                          : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                      }`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setGstMode('exclusive')}
                  className={`py-2 rounded-xl text-xs font-bold border ${
                    gstMode === 'exclusive'
                      ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                      : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                  }`}
                >
                  GST Exclusive (+ Add GST)
                </button>
                <button
                  type="button"
                  onClick={() => setGstMode('inclusive')}
                  className={`py-2 rounded-xl text-xs font-bold border ${
                    gstMode === 'inclusive'
                      ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                      : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                  }`}
                >
                  GST Inclusive (MRP Extract)
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 shadow-sm space-y-3">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-neutral-100 dark:border-neutral-800">
                <span className="text-neutral-500">Net Base Price:</span>
                <span className="font-bold text-neutral-800 dark:text-neutral-200">
                  ₹ {gst.base.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-500">CGST ({gstRate / 2}%):</span>
                <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                  ₹ {gst.cgst.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-neutral-100 dark:border-neutral-800">
                <span className="text-neutral-500">SGST ({gstRate / 2}%):</span>
                <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                  ₹ {gst.sgst.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm pt-1">
                <span className="font-extrabold text-neutral-900 dark:text-white">
                  Total Final Amount:
                </span>
                <span className="text-lg font-black text-[#FF6B00]">
                  ₹ {gst.total.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 3. EMI Calculator */}
      {toolId === 'calc-emi' && (() => {
        const emiData = computeEmi();
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3 shadow-sm text-xs">
              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>Loan Principal Amount</span>
                  <span className="text-[#FF6B00]">₹ {loanAmount.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="50000"
                  max="5000000"
                  step="25000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(parseInt(e.target.value, 10))}
                  className="w-full accent-[#FF6B00]"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>Interest Rate (% per annum)</span>
                  <span className="text-[#FF6B00]">{interestRate}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="24"
                  step="0.25"
                  value={interestRate}
                  onChange={(e) => setInterestRate(parseFloat(e.target.value))}
                  className="w-full accent-[#FF6B00]"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>Loan Tenure</span>
                  <span className="text-[#FF6B00]">{loanTenureYears} Years</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={loanTenureYears}
                  onChange={(e) => setLoanTenureYears(parseInt(e.target.value, 10))}
                  className="w-full accent-[#FF6B00]"
                />
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#FFF3E8] to-[#FFE4CC] dark:from-[#2A1706] dark:to-[#3D220A] border border-orange-200 dark:border-orange-800/60 rounded-3xl p-5 text-center shadow-sm space-y-4">
              <div>
                <span className="text-[10px] font-bold text-[#FF6B00] uppercase tracking-wider block">
                  Monthly EMI Payable
                </span>
                <div className="text-3xl font-black text-neutral-900 dark:text-white mt-0.5">
                  ₹ {emiData.emi.toLocaleString()}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-orange-200/60 dark:border-orange-800/40 text-left">
                <div className="bg-white/80 dark:bg-neutral-900/60 p-3 rounded-xl">
                  <span className="text-[10px] text-neutral-400 block font-semibold">Total Interest</span>
                  <span className="font-extrabold text-sm text-neutral-800 dark:text-neutral-100">
                    ₹ {emiData.totalInterest.toLocaleString()}
                  </span>
                </div>
                <div className="bg-white/80 dark:bg-neutral-900/60 p-3 rounded-xl">
                  <span className="text-[10px] text-neutral-400 block font-semibold">Total Amount</span>
                  <span className="font-extrabold text-sm text-neutral-800 dark:text-neutral-100">
                    ₹ {emiData.totalPayable.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 4. Date & Days Calculator */}
      {toolId === 'calc-date' && (() => {
        const diff = computeDateDiff();
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3 text-xs">
              <div>
                <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  value={d1}
                  onChange={(e) => setD1(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                />
              </div>
              <div>
                <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  End Date
                </label>
                <input
                  type="date"
                  value={d2}
                  onChange={(e) => setD2(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                />
              </div>
            </div>

            <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center shadow-sm">
              <span className="text-[10px] font-bold text-[#FF6B00] uppercase tracking-wider block">
                Difference Between Dates
              </span>
              <div className="text-3xl font-black text-neutral-900 dark:text-white mt-1">
                {diff.totalDays} <span className="text-sm font-semibold text-neutral-500">Days</span>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Equivalent to {diff.weeks} weeks and {diff.remDays} days
              </p>
            </div>
          </div>
        );
      })()}

      {/* 5. Percentage Calculator */}
      {toolId === 'calc-percentage' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Percentage (%)
                </label>
                <input
                  type="number"
                  value={pctVal1}
                  onChange={(e) => setPctVal1(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-bold"
                />
              </div>
              <div>
                <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Of Number
                </label>
                <input
                  type="number"
                  value={pctVal2}
                  onChange={(e) => setPctVal2(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-bold"
                />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center shadow-sm">
            <span className="text-[10px] font-bold text-[#FF6B00] uppercase tracking-wider block">
              {pctVal1}% of {pctVal2} is
            </span>
            <div className="text-3xl font-black text-[#FF6B00] mt-1">
              {((pctVal1 * pctVal2) / 100).toLocaleString()}
            </div>
          </div>
        </div>
      )}

      {/* 6. Smart Calculator */}
      {toolId === 'calc-standard' && (
        <div className="space-y-3">
          {/* Display */}
          <div className="bg-neutral-900 text-white rounded-3xl p-5 text-right font-mono shadow-md">
            <div className="h-5 text-neutral-400 text-xs truncate">
              {calcHistory[0] || ''}
            </div>
            <div className="text-3xl font-bold mt-1 overflow-x-auto hide-scrollbar">
              {calcDisplay}
            </div>
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-4 gap-2 text-base font-bold">
            {['C', '(', ')', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '%', '='].map(
              (btn) => {
                const isOp = ['÷', '×', '-', '+', '='].includes(btn);
                const isClear = btn === 'C';
                return (
                  <button
                    key={btn}
                    onClick={() => handleCalcPress(btn)}
                    className={`py-3.5 rounded-2xl transition-transform active:scale-95 ${
                      btn === '='
                        ? 'bg-[#FF6B00] text-white shadow-md shadow-orange-500/30'
                        : isOp
                        ? 'bg-orange-100 text-[#FF6B00] dark:bg-orange-950/60 dark:text-orange-300'
                        : isClear
                        ? 'bg-red-50 text-red-600 dark:bg-red-950/40'
                        : 'bg-white dark:bg-[#1E1F24] border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-100'
                    }`}
                  >
                    {btn}
                  </button>
                );
              }
            )}
          </div>
        </div>
      )}
    </div>
  );
};
