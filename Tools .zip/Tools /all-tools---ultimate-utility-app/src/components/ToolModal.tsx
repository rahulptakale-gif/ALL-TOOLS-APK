import React from 'react';
import { useApp } from '../context/AppContext';
import { Icon } from './Icon';
import { PdfTools } from './tools/PdfTools';
import { PdfMergeTool } from './tools/PdfMergeTool';
import { ImageTools } from './tools/ImageTools';
import { CscTools } from './tools/CscTools';
import { QrBarcodeTools } from './tools/QrBarcodeTools';
import { Calculators } from './tools/Calculators';
import { FileTools } from './tools/FileTools';
import { TextUtilityTools } from './tools/TextUtilityTools';
import { ArrowLeft, Heart, Wifi, ShieldCheck, X } from 'lucide-react';

export const ToolModal: React.FC = () => {
  const { activeTool, closeTool, isFavorite, toggleFavorite, getToolName, getToolDesc, t } = useApp();

  if (!activeTool) return null;

  const favorited = isFavorite(activeTool.id);

  // Render proper tool engine based on category or tool ID
  const renderToolEngine = () => {
    if (activeTool.id === 'pdf-merger') {
      return <PdfMergeTool />;
    }

    switch (activeTool.category) {
      case 'pdf':
        return <PdfTools toolId={activeTool.id} />;
      case 'image':
        return <ImageTools toolId={activeTool.id} />;
      case 'csc':
        return <CscTools toolId={activeTool.id} />;
      case 'qr':
        return <QrBarcodeTools toolId={activeTool.id} />;
      case 'calculator':
        return <Calculators toolId={activeTool.id} />;
      case 'converter':
        return <FileTools toolId={activeTool.id} />;
      case 'text':
        return <TextUtilityTools toolId={activeTool.id} />;
      default:
        return <PdfTools toolId={activeTool.id} />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-white dark:bg-[#121316] animate-slide-up overflow-hidden">
      {/* Sticky Modal Top Bar */}
      <header className="sticky top-0 z-20 bg-white/95 dark:bg-[#1A1B20]/95 backdrop-blur-md border-b border-orange-100 dark:border-neutral-800 px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={closeTool}
            className="p-2 -ml-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.25]" />
          </button>
          <div className="min-w-0">
            <h2 className="font-extrabold text-sm sm:text-base text-neutral-900 dark:text-neutral-100 truncate">
              {getToolName(activeTool)}
            </h2>
            <div className="flex items-center gap-2 text-[10px] text-neutral-400">
              <span className="uppercase font-bold text-[#FF6B00]">
                {activeTool.category}
              </span>
              <span aria-hidden="true">·</span>
              {activeTool.requiresInternet ? (
                <span className="flex items-center gap-1 text-sky-500 font-semibold">
                  <Wifi className="w-3 h-3" /> Online AI
                </span>
              ) : (
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                  <ShieldCheck className="w-3 h-3" /> 100% Offline / Local
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => toggleFavorite(activeTool.id)}
            className="p-2 rounded-xl text-neutral-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            title={favorited ? 'Remove favorite' : 'Add favorite'}
          >
            <Heart
              className={`w-5 h-5 ${
                favorited ? 'fill-red-500 text-red-500' : ''
              }`}
            />
          </button>
          <button
            onClick={closeTool}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Modal Content Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 max-w-[480px] w-full mx-auto space-y-4">
        {/* Tool Brief & Guidelines */}
        <div className="p-3 bg-orange-50/70 dark:bg-orange-950/30 rounded-2xl border border-orange-100 dark:border-neutral-800 text-xs text-neutral-600 dark:text-neutral-400 flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-orange-100 dark:bg-orange-900/60 text-[#FF6B00] flex items-center justify-center shrink-0 mt-0.5">
            <Icon name={activeTool.iconName} className="w-4 h-4" />
          </div>
          <p className="leading-relaxed">
            {getToolDesc(activeTool)}
          </p>
        </div>

        {/* Dynamic Tool Engine */}
        {renderToolEngine()}
      </div>
    </div>
  );
};
