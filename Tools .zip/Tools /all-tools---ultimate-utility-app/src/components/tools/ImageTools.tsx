import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';
import {
  Upload,
  Download,
  Image as ImageIcon,
  Minimize2,
  Maximize2,
  Crop,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  Sliders,
  FlipHorizontal,
  Stamp,
  Layers,
  Printer,
} from 'lucide-react';

interface ImageToolsProps {
  toolId: string;
}

export const ImageTools: React.FC<ImageToolsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultFileName, setResultFileName] = useState<string>('');
  const [resultSizeKb, setResultSizeKb] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  // Settings
  const [targetKb, setTargetKb] = useState<number>(50);
  const [resizeWidth, setResizeWidth] = useState<number>(800);
  const [resizeHeight, setResizeHeight] = useState<number>(600);
  const [keepAspect, setKeepAspect] = useState<boolean>(true);
  const [originalAspect, setOriginalAspect] = useState<number>(1);
  const [outputFormat, setOutputFormat] = useState<'image/jpeg' | 'image/png' | 'image/webp'>('image/jpeg');

  // Enhancer adjustments
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [saturation, setSaturation] = useState<number>(100);

  // Crop / Passport
  const [cropAspect, setCropAspect] = useState<'1:1' | '3.5:4.5' | '4:3' | '16:9'>('3.5:4.5');
  const [passportCopies, setPassportCopies] = useState<number>(8);

  // Watermark text
  const [watermarkText, setWatermarkText] = useState<string>('CSC PHOTO STUDIO');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      setResultUrl(null);
      setError(null);

      // Measure dimensions
      const img = new Image();
      img.onload = () => {
        setResizeWidth(img.width);
        setResizeHeight(img.height);
        setOriginalAspect(img.width / img.height);
      };
      img.src = url;
    }
  };

  const handleWidthChange = (w: number) => {
    setResizeWidth(w);
    if (keepAspect && originalAspect) {
      setResizeHeight(Math.round(w / originalAspect));
    }
  };

  const handleClear = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setResultUrl(null);
    setError(null);
  };

  // Main processing engine
  const processImage = async () => {
    if (!previewUrl || !selectedFile) return;

    try {
      setProcessing(true);
      setError(null);

      const img = new Image();
      img.crossOrigin = 'anonymous';
      await new Promise((res, rej) => {
        img.onload = res;
        img.onerror = rej;
        img.src = previewUrl;
      });

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas context not available');

      // 1. Image Compressor (Target KB)
      if (toolId === 'img-compressor') {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);

        // Binary search for exact JPEG quality to hit target KB
        let minQ = 0.05;
        let maxQ = 0.98;
        let bestBlob: Blob | null = null;
        let bestQuality = 0.8;

        for (let iter = 0; iter < 7; iter++) {
          const midQ = (minQ + maxQ) / 2;
          const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', midQ));
          const sizeKb = blob.size / 1024;
          bestBlob = blob;
          bestQuality = midQ;

          if (sizeKb > targetKb) {
            maxQ = midQ;
          } else {
            minQ = midQ;
          }
        }

        // If even lowest quality is larger than targetKb, downscale dimensions
        if (bestBlob && bestBlob.size / 1024 > targetKb * 1.2) {
          const scale = Math.sqrt((targetKb * 1024) / bestBlob.size);
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          bestBlob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.8));
        }

        if (bestBlob) {
          const url = URL.createObjectURL(bestBlob);
          setResultUrl(url);
          setResultSizeKb(bestBlob.size / 1024);
          const name = `Compressed_${Math.round(bestBlob.size / 1024)}KB_${selectedFile.name.replace(/\.[^.]+$/, '')}.jpg`;
          setResultFileName(name);
          addToHistory(toolId, `Compressed to ${Math.round(bestBlob.size / 1024)} KB`, name);
        }
      }

      // 2. Image Resizer
      else if (toolId === 'img-resizer') {
        canvas.width = resizeWidth;
        canvas.height = resizeHeight;
        ctx.drawImage(img, 0, 0, resizeWidth, resizeHeight);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.92));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Resized_${resizeWidth}x${resizeHeight}_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Resized to ${resizeWidth}x${resizeHeight}px`, name);
      }

      // 3. Image Cropper
      else if (toolId === 'img-cropper') {
        // Compute crop bounds centered
        let targetRatio = 1;
        if (cropAspect === '3.5:4.5') targetRatio = 3.5 / 4.5;
        else if (cropAspect === '4:3') targetRatio = 4 / 3;
        else if (cropAspect === '16:9') targetRatio = 16 / 9;

        const currentRatio = img.width / img.height;
        let cropW = img.width;
        let cropH = img.height;
        let startX = 0;
        let startY = 0;

        if (currentRatio > targetRatio) {
          cropW = img.height * targetRatio;
          startX = (img.width - cropW) / 2;
        } else {
          cropH = img.width / targetRatio;
          startY = (img.height - cropH) / 2;
        }

        canvas.width = cropW;
        canvas.height = cropH;
        ctx.drawImage(img, startX, startY, cropW, cropH, 0, 0, cropW, cropH);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Cropped_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Cropped to ${cropAspect} ratio`, name);
      }

      // 4. Passport Photo 8-Up Sheet Maker (Indian Standard 3.5cm x 4.5cm on 4x6 / A4 sheet)
      else if (toolId === 'img-passport-maker') {
        // First crop center to 3.5:4.5 passport aspect ratio
        const pRatio = 3.5 / 4.5;
        let pW = img.width;
        let pH = img.height;
        let pX = 0;
        let pY = 0;
        if (img.width / img.height > pRatio) {
          pW = img.height * pRatio;
          pX = (img.width - pW) / 2;
        } else {
          pH = img.width / pRatio;
          pY = (img.height - pH) / 2;
        }

        const singleCanvas = document.createElement('canvas');
        singleCanvas.width = 413; // 3.5cm at 300 DPI
        singleCanvas.height = 531; // 4.5cm at 300 DPI
        const sCtx = singleCanvas.getContext('2d')!;
        sCtx.drawImage(img, pX, pY, pW, pH, 0, 0, singleCanvas.width, singleCanvas.height);
        // Add subtle cutting border
        sCtx.strokeStyle = '#D1D5DB';
        sCtx.lineWidth = 2;
        sCtx.strokeRect(1, 1, singleCanvas.width - 2, singleCanvas.height - 2);

        // Standard 4x6 inch print sheet at 300 DPI: 1800 x 1200 px
        canvas.width = 1800;
        canvas.height = 1200;
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Arrange 8 photos (4 columns x 2 rows)
        const cols = 4;
        const rows = 2;
        const marginX = 60;
        const marginY = 60;
        const gapX = 30;
        const gapY = 30;

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const posX = marginX + c * (singleCanvas.width + gapX);
            const posY = marginY + r * (singleCanvas.height + gapY);
            ctx.drawImage(singleCanvas, posX, posY);
          }
        }

        // Sheet Header label for print
        ctx.fillStyle = '#6B7280';
        ctx.font = '24px sans-serif';
        ctx.fillText('ALL TOOLS · Passport Size 3.5x4.5cm (Ready to Print on 4x6" Glossy Paper)', marginX, canvas.height - 30);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Passport_8_Photo_Sheet_4x6_${Date.now()}.jpg`;
        setResultFileName(name);
        addToHistory(toolId, 'Created 8-photo Passport Print Sheet', name);
      }

      // 5. Image Format Converter (JPG / PNG / WEBP)
      else if (toolId === 'img-format-converter') {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);

        const ext = outputFormat === 'image/png' ? 'png' : outputFormat === 'image/webp' ? 'webp' : 'jpg';
        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), outputFormat, 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `${selectedFile.name.replace(/\.[^.]+$/, '')}.${ext}`;
        setResultFileName(name);
        addToHistory(toolId, `Converted to ${ext.toUpperCase()}`, name);
      }

      // 6. Photo Enhancer
      else if (toolId === 'img-enhancer') {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
        ctx.drawImage(img, 0, 0);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Enhanced_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Enhanced brightness (${brightness}%) and contrast (${contrast}%)`, name);
      }

      // 7. Image Rotator & Flip
      else if (toolId === 'img-rotator') {
        canvas.width = img.height;
        canvas.height = img.width;
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((90 * Math.PI) / 180);
        ctx.drawImage(img, -img.width / 2, -img.height / 2);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Rotated_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, 'Rotated 90° clockwise', name);
      }

      // 8. Image Watermark & Stamp
      else if (toolId === 'img-watermark') {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);

        // Watermark stamp in bottom-right corner
        const stampText = watermarkText || 'CSC PHOTO STUDIO';
        const fontSize = Math.max(16, Math.round(canvas.width / 35));
        ctx.font = `bold ${fontSize}px sans-serif`;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        const textMetrics = ctx.measureText(stampText);
        const pad = 12;
        const boxX = canvas.width - textMetrics.width - pad * 2 - 20;
        const boxY = canvas.height - fontSize - pad * 2 - 20;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(boxX, boxY, textMetrics.width + pad * 2, fontSize + pad * 2);

        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(stampText, boxX + pad, boxY + pad + fontSize - 4);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Watermarked_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Watermarked with "${stampText}"`, name);
      }

      // 9. Photo Collage
      else {
        // Duplicate 2 side-by-side
        canvas.width = img.width * 2 + 20;
        canvas.height = img.height;
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        ctx.drawImage(img, img.width + 20, 0);

        const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        setResultSizeKb(blob.size / 1024);
        const name = `Collage_${selectedFile.name}`;
        setResultFileName(name);
        addToHistory(toolId, 'Created photo collage', name);
      }

      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Image processing failed');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Upload Zone */}
      {!resultUrl && (
        <div className="space-y-3">
          <div className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm">
              <Upload className="w-6 h-6 stroke-[2]" />
            </div>
            <h3 className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
              {previewUrl ? 'Change Selected Photo' : t('dropFiles')}
            </h3>
            <p className="text-[11px] text-neutral-500 mt-1">
              Supports JPG, PNG, WEBP, JPEG up to 50MB (100% on-device)
            </p>
          </div>

          {/* Preview & Original Info */}
          {previewUrl && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-3 flex items-center gap-3">
              <img
                src={previewUrl}
                alt="Selected"
                className="w-16 h-16 object-cover rounded-xl border border-neutral-200 dark:border-neutral-700 shrink-0"
              />
              <div className="min-w-0">
                <p className="font-bold text-xs text-neutral-800 dark:text-neutral-200 truncate">
                  {selectedFile?.name}
                </p>
                <p className="text-[10px] text-neutral-400 mt-0.5">
                  Original: {((selectedFile?.size || 0) / 1024).toFixed(1)} KB · {resizeWidth} × {resizeHeight} px
                </p>
              </div>
            </div>
          )}

          {/* Tool-specific Settings */}
          {previewUrl && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-3.5 space-y-3">
              {/* Target KB Compressor */}
              {toolId === 'img-compressor' && (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                      Target File Size
                    </label>
                    <span className="text-xs font-extrabold text-[#FF6B00]">
                      {targetKb} KB
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="500"
                    step="5"
                    value={targetKb}
                    onChange={(e) => setTargetKb(parseInt(e.target.value, 10))}
                    className="w-full accent-[#FF6B00]"
                  />
                  <div className="flex justify-between gap-1.5 mt-2">
                    {[20, 50, 100, 200, 300].map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setTargetKb(size)}
                        className={`flex-1 py-1 rounded-lg text-[10px] font-bold border ${
                          targetKb === size
                            ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                            : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                        }`}
                      >
                        {size} KB
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Resizer Settings */}
              {toolId === 'img-resizer' && (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="text-[11px] font-bold text-neutral-500 mb-1 block">Width (px)</label>
                      <input
                        type="number"
                        value={resizeWidth}
                        onChange={(e) => handleWidthChange(parseInt(e.target.value, 10) || 0)}
                        className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-neutral-500 mb-1 block">Height (px)</label>
                      <input
                        type="number"
                        value={resizeHeight}
                        onChange={(e) => setResizeHeight(parseInt(e.target.value, 10) || 0)}
                        className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                      />
                    </div>
                  </div>
                  <label className="flex items-center gap-2 text-xs font-medium text-neutral-600 dark:text-neutral-400">
                    <input
                      type="checkbox"
                      checked={keepAspect}
                      onChange={(e) => setKeepAspect(e.target.checked)}
                      className="accent-[#FF6B00]"
                    />
                    Maintain aspect ratio
                  </label>
                </div>
              )}

              {/* Cropper Presets */}
              {toolId === 'img-cropper' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1.5">
                    Aspect Ratio
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: '3.5:4.5', label: 'Passport' },
                      { id: '1:1', label: '1:1 Square' },
                      { id: '4:3', label: '4:3 Photo' },
                      { id: '16:9', label: '16:9 Wide' },
                    ].map((asp) => (
                      <button
                        key={asp.id}
                        type="button"
                        onClick={() => setCropAspect(asp.id as any)}
                        className={`py-1.5 text-[11px] font-bold rounded-xl border ${
                          cropAspect === asp.id
                            ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                            : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                        }`}
                      >
                        {asp.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Passport Photo 8-Photo Sheet */}
              {toolId === 'img-passport-maker' && (
                <div className="p-2.5 bg-orange-50/60 dark:bg-orange-950/30 rounded-xl border border-orange-100 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-[#FF6B00] mb-1">
                    <Printer className="w-4 h-4" />
                    <span>CSC Instant 8-Photo 4x6&quot; Sheet</span>
                  </div>
                  <p className="text-[11px] text-neutral-600 dark:text-neutral-400 leading-normal">
                    Automatically crops 3.5cm x 4.5cm Indian standard passport size with cutting lines and generates an 8-photo layout ready to print.
                  </p>
                </div>
              )}

              {/* Format Converter */}
              {toolId === 'img-format-converter' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1.5">
                    Target Format
                  </label>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    {[
                      { format: 'image/jpeg', label: 'JPG / JPEG' },
                      { format: 'image/png', label: 'PNG' },
                      { format: 'image/webp', label: 'WebP' },
                    ].map((fmt) => (
                      <button
                        key={fmt.format}
                        type="button"
                        onClick={() => setOutputFormat(fmt.format as any)}
                        className={`py-2 rounded-xl font-bold border ${
                          outputFormat === fmt.format
                            ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                            : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                        }`}
                      >
                        {fmt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Photo Enhancer */}
              {toolId === 'img-enhancer' && (
                <div className="space-y-2.5 text-xs">
                  <div>
                    <div className="flex justify-between font-bold text-neutral-600 text-[11px]">
                      <span>Brightness</span>
                      <span>{brightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="150"
                      value={brightness}
                      onChange={(e) => setBrightness(parseInt(e.target.value, 10))}
                      className="w-full accent-[#FF6B00]"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between font-bold text-neutral-600 text-[11px]">
                      <span>Contrast</span>
                      <span>{contrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="150"
                      value={contrast}
                      onChange={(e) => setContrast(parseInt(e.target.value, 10))}
                      className="w-full accent-[#FF6B00]"
                    />
                  </div>
                </div>
              )}

              {/* Watermark text */}
              {toolId === 'img-watermark' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Watermark / Studio Name
                  </label>
                  <input
                    type="text"
                    value={watermarkText}
                    onChange={(e) => setWatermarkText(e.target.value)}
                    placeholder="e.g. MAHA E-SEVA / CSC CENTER"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-xl text-xs font-medium">
              {error}
            </div>
          )}

          {/* Process Button */}
          {previewUrl && (
            <button
              onClick={processImage}
              disabled={processing}
              className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] active:scale-[0.99] text-white font-bold text-sm rounded-2xl shadow-md shadow-orange-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{t('processing')}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{t('processFile')}</span>
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* Result Display & Download */}
      {resultUrl && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm animate-scale-up">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
          </div>

          <div>
            <h3 className="font-extrabold text-base text-neutral-900 dark:text-neutral-100">
              {t('success')}
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Result: {resultSizeKb.toFixed(1)} KB · Ready to save
            </p>
          </div>

          <div className="max-w-[280px] mx-auto rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-700 shadow-sm">
            <img src={resultUrl} alt="Processed Result" className="w-full max-h-60 object-contain bg-neutral-100" />
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <a
              href={resultUrl}
              download={resultFileName}
              className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] active:scale-[0.99] text-white font-bold text-xs rounded-2xl shadow-md shadow-orange-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{t('downloadResult')}</span>
            </a>

            <button
              onClick={handleClear}
              className="w-full py-2.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-2xl transition-colors"
            >
              Process Another Photo
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
