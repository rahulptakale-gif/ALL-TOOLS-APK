import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Globe,
  Moon,
  Sun,
  Shield,
  FileText,
  HelpCircle,
  Star,
  Share2,
  Info,
  Check,
  ChevronRight,
  Sparkles,
  Lock,
  Download,
  Smartphone,
} from 'lucide-react';
import { Language } from '../../types';

export const SettingsView: React.FC = () => {
  const { theme, setTheme, language, setLanguage, t } = useApp();
  const [modalContent, setModalContent] = useState<{ title: string; content: React.ReactNode } | null>(null);
  const [copiedShare, setCopiedShare] = useState(false);

  const languages: { code: Language; name: string; native: string }[] = [
    { code: 'en', name: 'English', native: 'English' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
    { code: 'mr', name: 'Marathi', native: 'मराठी' },
  ];

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'ALL TOOLS - Ultimate Utility App',
        text: 'One App – All Useful Tools in Your Pocket! Try CSC & daily utility tools.',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    }
  };

  const handleRate = () => {
    alert('Thank you for using ALL TOOLS! Your 5-star rating supports offline utility development.');
  };

  const openPrivacyModal = () => {
    setModalContent({
      title: 'Privacy & Data Security Policy',
      content: (
        <div className="space-y-3 text-xs leading-relaxed text-neutral-600 dark:text-neutral-300">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-emerald-800 dark:text-emerald-300">100% On-Device Client Processing</p>
              <p className="mt-0.5 text-emerald-700 dark:text-emerald-400">
                Your Aadhaar, PAN, Voter IDs, certificates, signatures, and personal photos are processed exclusively inside your device browser memory. They are NEVER sent to or stored on any central server.
              </p>
            </div>
          </div>
          <p>
            <strong>Zero Data Retention:</strong> All uploaded files and preview canvases are wiped when you close or reload the tool. We do not maintain any logs of your documents.
          </p>
          <p>
            <strong>Official CSC Disclaimer:</strong> ALL TOOLS provides formatting and preparation utilities. It is not an official government portal. It never requests or stores Aadhaar OTPs, passwords, or banking PINs.
          </p>
          <p>
            <strong>AI Multimodal Processing:</strong> Multilingual OCR (Hindi/Marathi/English) utilizes the Google Gemini API to extract text on-demand. Extracted text is immediately presented to you and discarded.
          </p>
        </div>
      ),
    });
  };

  const openTermsModal = () => {
    setModalContent({
      title: 'Terms of Service',
      content: (
        <div className="space-y-3 text-xs leading-relaxed text-neutral-600 dark:text-neutral-300">
          <p>
            1. <strong>Acceptance:</strong> By using ALL TOOLS, you agree to utilize these utilities for lawful and authorized document preparation, image editing, and file conversion.
          </p>
          <p>
            2. <strong>Identity Documents:</strong> Users are solely responsible for ensuring they possess legal rights or authorized customer consent when processing Aadhaar, PAN, and other certificates at CSC / Cyber Cafe counters.
          </p>
          <p>
            3. <strong>Availability:</strong> Offline-capable tools run locally without internet. Features requiring internet (such as AI OCR) rely on active connectivity.
          </p>
        </div>
      ),
    });
  };

  const openAboutModal = () => {
    setModalContent({
      title: 'About ALL TOOLS',
      content: (
        <div className="space-y-3 text-xs leading-relaxed text-neutral-600 dark:text-neutral-300">
          <div className="flex items-center gap-3 p-3 bg-orange-50 dark:bg-orange-950/40 rounded-2xl border border-orange-200 dark:border-orange-800">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#FF6B00] to-[#FFA726] flex items-center justify-center text-white shadow-sm font-black text-xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">ALL TOOLS Pro</h4>
              <p className="text-[11px] text-[#E65100] dark:text-orange-400 font-medium">
                One App – All Useful Tools in Your Pocket
              </p>
              <p className="text-[10px] text-neutral-400 mt-0.5">Version 2.4.0 (CSC Digital Edition)</p>
            </div>
          </div>
          <p>
            Built specifically for Indian CSC operators, Maha E-Seva centers, cyber cafe shop owners, students, and everyday mobile users who need reliable, fast utilities without clutter or ads.
          </p>
          <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-neutral-500">Theme</span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200">Modern Orange & White</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Security Engine</span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200">Client-Side Sandbox</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Multilingual</span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200">English, हिन्दी, मराठी</span>
            </div>
          </div>
        </div>
      ),
    });
  };

  const openAndroidExportModal = () => {
    setModalContent({
      title: 'How to Build Android APK',
      content: (
        <div className="space-y-3.5 text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed">
          <div className="p-3 bg-orange-50 dark:bg-orange-950/40 rounded-xl border border-orange-200 dark:border-orange-800">
            <p className="font-bold text-[#FF6B00] mb-0.5">Ready for Android Studio</p>
            <p className="text-[11px] text-neutral-600 dark:text-neutral-400">
              The project is pre-configured with Android SDK 34, Camera & File Provider permissions, and embedded offline assets.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1 flex items-center gap-1.5">
              <span>Step 1: Download & Extract ZIP</span>
            </h4>
            <p className="text-[11px] text-neutral-500">
              Download <strong>ALL_TOOLS_Android_Studio_Project.zip</strong> and extract it into a folder on your PC or Mac.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1 flex items-center gap-1.5">
              <span>Step 2: Open in Android Studio</span>
            </h4>
            <p className="text-[11px] text-neutral-500">
              Launch Android Studio, click <strong>File &gt; Open...</strong>, and select the extracted <code className="bg-neutral-100 dark:bg-neutral-800 px-1 py-0.5 rounded font-mono text-[10px]">android</code> directory.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1 flex items-center gap-1.5">
              <span>Step 3: Generate APK</span>
            </h4>
            <p className="text-[11px] text-neutral-500">
              From the top menu, click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>. Your APK will be compiled into <code className="bg-neutral-100 dark:bg-neutral-800 px-1 py-0.5 rounded font-mono text-[10px]">app/build/outputs/apk/debug/app-debug.apk</code>.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1 flex items-center gap-1.5">
              <span>Terminal CLI Alternative</span>
            </h4>
            <p className="text-[11px] text-neutral-500 font-mono bg-neutral-100 dark:bg-neutral-800 p-2 rounded-xl">
              cd android<br />
              ./gradlew assembleDebug
            </p>
          </div>

          <div className="pt-2">
            <a
              href="/api/export-project-zip"
              download="ALL_TOOLS_Android_Studio_Project.zip"
              className="w-full py-2.5 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-sm transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Project ZIP (1.2 MB)</span>
            </a>
          </div>
        </div>
      ),
    });
  };

  return (
    <div className="px-4 py-4 pb-28 space-y-5">
      <div>
        <h1 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
          {t('settingsTitle')}
        </h1>
        <p className="text-xs text-neutral-500">
          Personalize language, theme appearance and app preferences
        </p>
      </div>

      {/* Android Studio Project Export Banner Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#FF6B00] via-[#FF8A00] to-[#FFA726] p-4 text-white shadow-md shadow-orange-500/20">
        <div className="relative z-10 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[10px] font-bold text-white">
              <Smartphone className="w-3 h-3" />
              <span>Android Studio Ready</span>
            </div>
            <span className="text-[10px] text-orange-100 font-semibold">Ready to Build APK</span>
          </div>

          <div>
            <h3 className="font-extrabold text-base tracking-tight leading-snug">
              Export Complete Android Project
            </h3>
            <p className="text-xs text-orange-100 mt-0.5 leading-relaxed">
              Includes full source code, components, offline assets, and Android Studio Gradle wrapper project.
            </p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <a
              href="/api/export-project-zip"
              download="ALL_TOOLS_Android_Studio_Project.zip"
              className="flex-1 py-2.5 px-3 bg-white text-[#E65100] hover:bg-orange-50 active:scale-95 font-bold text-xs rounded-xl shadow-sm transition-transform flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4 text-[#FF6B00]" />
              <span>Download Project ZIP</span>
            </a>
            <button
              onClick={openAndroidExportModal}
              className="py-2.5 px-3 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl backdrop-blur-md transition-colors"
            >
              Build Guide
            </button>
          </div>
        </div>
      </div>

      {/* Language Section */}
      <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Globe className="w-4 h-4 text-[#FF6B00]" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
            {t('language')}
          </h2>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {languages.map((l) => {
            const isSelected = language === l.code;
            return (
              <button
                key={l.code}
                onClick={() => setLanguage(l.code)}
                className={`py-2 px-3 rounded-xl border text-xs font-medium flex flex-col items-center gap-0.5 transition-all ${
                  isSelected
                    ? 'border-[#FF6B00] bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] dark:text-orange-400 font-bold shadow-sm'
                    : 'border-neutral-200 dark:border-neutral-700 hover:border-orange-200 text-neutral-700 dark:text-neutral-300'
                }`}
              >
                <span>{l.native}</span>
                <span className="text-[10px] text-neutral-400">{l.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Theme & Display */}
      <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {theme === 'dark' ? (
              <Moon className="w-4 h-4 text-amber-400" />
            ) : (
              <Sun className="w-4 h-4 text-[#FF6B00]" />
            )}
            <div>
              <h3 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                {t('darkMode')}
              </h3>
              <p className="text-[11px] text-neutral-400">
                {theme === 'dark' ? 'Dark theme enabled' : 'Clean white & bright orange theme'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
              theme === 'dark' ? 'bg-[#FF6B00]' : 'bg-neutral-200 dark:bg-neutral-700'
            }`}
            aria-label="Toggle theme"
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                theme === 'dark' ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Information & Links */}
      <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl divide-y divide-neutral-100 dark:divide-neutral-800 shadow-sm overflow-hidden">
        <button
          onClick={openPrivacyModal}
          className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {t('privacyPolicy')}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        <button
          onClick={openTermsModal}
          className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <FileText className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {t('terms')}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        <button
          onClick={openAboutModal}
          className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Info className="w-4 h-4 text-[#FF6B00]" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {t('about')}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        <button
          onClick={handleShare}
          className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Share2 className="w-4 h-4 text-purple-600" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {copiedShare ? t('copied') : t('shareApp')}
            </span>
          </div>
          {copiedShare ? (
            <Check className="w-4 h-4 text-emerald-600" />
          ) : (
            <ChevronRight className="w-4 h-4 text-neutral-400" />
          )}
        </button>

        <button
          onClick={handleRate}
          className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {t('rateApp')}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>
      </div>

      {/* App Footer Stamp */}
      <div className="text-center pt-2">
        <p className="text-[11px] font-bold text-neutral-400">
          ALL TOOLS · {t('tagline')}
        </p>
        <p className="text-[10px] text-neutral-400 mt-0.5">
          Designed with Orange & White Google-style Simplicity
        </p>
      </div>

      {/* Info Modal */}
      {modalContent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-[#1E1F24] rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-orange-100 dark:border-neutral-800 animate-scale-up">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                {modalContent.title}
              </h3>
              <button
                onClick={() => setModalContent(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
              >
                ✕
              </button>
            </div>
            <div className="py-3 max-h-[60vh] overflow-y-auto">
              {modalContent.content}
            </div>
            <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800">
              <button
                onClick={() => setModalContent(null)}
                className="w-full py-2 bg-[#FF6B00] text-white font-bold text-xs rounded-xl hover:bg-[#E65100] transition-colors"
              >
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
