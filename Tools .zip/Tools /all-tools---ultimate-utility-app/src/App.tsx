import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { BottomNav } from './components/BottomNav';
import { HomeDashboard } from './components/HomeDashboard';
import { FavoritesView } from './components/views/FavoritesView';
import { HistoryView } from './components/views/HistoryView';
import { SettingsView } from './components/views/SettingsView';
import { ToolModal } from './components/ToolModal';

const AppContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="app-container bg-[#F8F9FA] dark:bg-[#121316] text-[#202124] dark:text-[#F1F3F4] min-h-screen transition-colors duration-200">
      {/* Top Header */}
      <Header />

      {/* Main Tab Router */}
      <main className="w-full">
        {activeTab === 'home' && (
          <>
            <SearchBar />
            <HomeDashboard />
          </>
        )}
        {activeTab === 'favorites' && <FavoritesView />}
        {activeTab === 'history' && <HistoryView />}
        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav />

      {/* Full-screen Tool Execution Modal */}
      <ToolModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
