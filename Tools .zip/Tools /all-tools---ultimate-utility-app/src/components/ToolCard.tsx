import React from 'react';
import { ToolItem } from '../types';
import { useApp } from '../context/AppContext';
import { Icon } from './Icon';
import { Heart, ChevronRight, Wifi } from 'lucide-react';

interface ToolCardProps {
  tool: ToolItem;
  featured?: boolean;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, featured = false }) => {
  const { openTool, isFavorite, toggleFavorite, getToolName, getToolDesc } = useApp();
  const favorited = isFavorite(tool.id);

  // Category specific icon colors
  const categoryStyles: Record<string, { bg: string; text: string }> = {
    csc: { bg: 'bg-emerald-50 dark:bg-emerald-950/40', text: 'text-emerald-600 dark:text-emerald-400' },
    pdf: { bg: 'bg-red-50 dark:bg-red-950/40', text: 'text-red-600 dark:text-red-400' },
    image: { bg: 'bg-amber-50 dark:bg-amber-950/40', text: 'text-amber-600 dark:text-amber-400' },
    qr: { bg: 'bg-blue-50 dark:bg-blue-950/40', text: 'text-blue-600 dark:text-blue-400' },
    calculator: { bg: 'bg-orange-50 dark:bg-orange-950/40', text: 'text-[#FF6B00] dark:text-[#FFA726]' },
    converter: { bg: 'bg-purple-50 dark:bg-purple-950/40', text: 'text-purple-600 dark:text-purple-400' },
    text: { bg: 'bg-teal-50 dark:bg-teal-950/40', text: 'text-teal-600 dark:text-teal-400' },
  };

  const style = categoryStyles[tool.category] || {
    bg: 'bg-orange-50 dark:bg-orange-950/40',
    text: 'text-[#FF6B00]',
  };

  return (
    <div
      onClick={() => openTool(tool.id)}
      className={`group relative text-left bg-white dark:bg-[#1E1F24] border border-orange-100/70 dark:border-neutral-800 rounded-2xl p-3.5 transition-all duration-200 hover:shadow-md hover:border-orange-300 dark:hover:border-neutral-700 active:scale-[0.98] cursor-pointer flex flex-col justify-between ${
        featured ? 'ring-1 ring-[#FF6B00]/30 shadow-sm' : ''
      }`}
    >
      <div>
        <div className="flex items-start justify-between gap-2 mb-2">
          {/* Tool Icon */}
          <div
            className={`w-10 h-10 rounded-xl ${style.bg} ${style.text} flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 shadow-sm`}
          >
            <Icon name={tool.iconName} className="w-5 h-5" />
          </div>

          {/* Favorite Toggle Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(tool.id);
            }}
            className="p-1.5 rounded-full text-neutral-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            title={favorited ? 'Remove from favorites' : 'Add to favorites'}
            aria-label="Toggle Favorite"
          >
            <Heart
              className={`w-4 h-4 transition-transform ${
                favorited ? 'fill-red-500 text-red-500 scale-110' : ''
              }`}
            />
          </button>
        </div>

        {/* Title */}
        <h3 className="font-bold text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug group-hover:text-[#FF6B00] dark:group-hover:text-[#FFA726] transition-colors line-clamp-1">
          {getToolName(tool)}
        </h3>

        {/* Description */}
        <p className="mt-1 text-[11px] text-neutral-500 dark:text-neutral-400 leading-normal line-clamp-2">
          {getToolDesc(tool)}
        </p>
      </div>

      {/* Card Footer with clean unboxed metadata (anti-pill discipline) */}
      <div className="mt-3 pt-2.5 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-[10px] text-neutral-400 dark:text-neutral-500">
        <div className="flex items-center gap-1.5 truncate">
          {tool.badge && (
            <>
              <span className="font-semibold text-[#FF6B00] dark:text-[#FFA726]">{tool.badge}</span>
              <span aria-hidden="true">·</span>
            </>
          )}
          {tool.requiresInternet ? (
            <span className="flex items-center gap-1 text-sky-600 dark:text-sky-400">
              <Wifi className="w-3 h-3" /> Online AI
            </span>
          ) : (
            <span>Offline Ready</span>
          )}
        </div>

        <div className="flex items-center text-[#FF6B00] dark:text-[#FFA726] font-semibold group-hover:translate-x-0.5 transition-transform">
          <ChevronRight className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};
