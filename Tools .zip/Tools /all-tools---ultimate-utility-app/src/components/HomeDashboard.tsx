import React from 'react';
import { useApp } from '../context/AppContext';
import { ALL_TOOLS_LIST, CATEGORIES } from '../data/tools';
import { ToolCard } from './ToolCard';
import { RecentFilesSection } from './RecentFilesSection';
import { Sparkles, ShieldCheck, Flame, History, ArrowRight, Zap, ExternalLink, Download } from 'lucide-react';
import { ToolCategory } from '../types';

export const HomeDashboard: React.FC = () => {
  const {
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    openTool,
    history,
    t,
  } = useApp();

  // Filter tools based on search query or selected category
  const filteredTools = ALL_TOOLS_LIST.filter((tool) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tool.name.toLowerCase().includes(q) ||
        tool.nameHi.toLowerCase().includes(q) ||
        tool.nameMr.toLowerCase().includes(q) ||
        tool.description.toLowerCase().includes(q) ||
        tool.descriptionHi.toLowerCase().includes(q) ||
        tool.descriptionMr.toLowerCase().includes(q) ||
        tool.category.toLowerCase().includes(q)
      );
    }

    if (selectedCategory !== 'all') {
      return tool.category === selectedCategory;
    }

    return true;
  });

  const popularTools = ALL_TOOLS_LIST.filter((tool) => tool.isPopular).slice(0, 6);
  const dailyTools = ALL_TOOLS_LIST.filter((tool) => tool.isDaily).slice(0, 4);

  // Recent tools resolved from history
  const recentToolIds = Array.from(new Set(history.map((h) => h.toolId))).slice(0, 4);
  const recentTools = recentToolIds
    .map((id) => ALL_TOOLS_LIST.find((t) => t.id === id))
    .filter(Boolean) as typeof ALL_TOOLS_LIST;

  return (
    <div className="pb-24 space-y-5">
      {/* Search active indicator */}
      {searchQuery.trim() ? (
        <div className="px-4">
          <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-3">
            <span>
              Found <strong className="text-[#FF6B00]">{filteredTools.length}</strong> tools for &ldquo;{searchQuery}&rdquo;
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filteredTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
          {filteredTools.length === 0 && (
            <div className="text-center py-12 px-4 bg-white dark:bg-[#1E1F24] rounded-2xl border border-neutral-200 dark:border-neutral-800">
              <p className="text-sm font-semibold text-neutral-700 dark:text-neutral-300">
                No matching tools found
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                Try searching for &quot;PDF&quot;, &quot;Photo&quot;, &quot;Aadhaar&quot;, &quot;GST&quot;, or &quot;QR&quot;
              </p>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Hero Welcome Banner */}
          <div className="px-4">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#FF6B00] via-[#FF8A00] to-[#FF9E2C] text-white p-5 shadow-lg shadow-orange-500/20">
              {/* Background decorative circles */}
              <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-white/10 blur-xl pointer-events-none" />
              <div className="absolute top-2 right-4 w-20 h-20 rounded-full bg-amber-300/20 blur-md pointer-events-none" />

              <div className="relative z-10">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold text-white mb-2.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                  <span>CSC Digital India & Daily Utilities Suite</span>
                </div>
                <h1 className="text-xl font-extrabold tracking-tight leading-snug">
                  One App. 40+ Powerful Tools.
                </h1>
                <p className="text-xs text-orange-100 mt-1 max-w-[280px] leading-relaxed">
                  Fast, secure & private. Process Aadhaar, PAN, PDFs, Photos & Calculators without internet leaks.
                </p>

                {/* Quick Action Buttons */}
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => openTool('csc-aadhaar')}
                    className="px-3 py-1.5 bg-white text-[#E65100] hover:bg-orange-50 font-bold text-xs rounded-xl shadow-sm transition-transform active:scale-95 flex items-center gap-1.5"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-[#FF6B00]" />
                    <span>Aadhaar Xerox</span>
                  </button>
                  <button
                    onClick={() => openTool('csc-photo-reducer')}
                    className="px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl backdrop-blur-md transition-colors flex items-center gap-1"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Photo 20-50KB</span>
                  </button>
                  <button
                    onClick={() => openTool('pdf-merger')}
                    className="px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl backdrop-blur-md transition-colors"
                  >
                    Merge PDF
                  </button>
                  <a
                    href="/api/export-project-zip"
                    download="ALL_TOOLS_Android_Studio_Project.zip"
                    className="px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl backdrop-blur-md transition-colors flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export APK (.ZIP)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Categories Segmented Bar */}
          <div className="px-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                {t('categories')}
              </h2>
              <span className="text-[11px] text-neutral-400">
                {ALL_TOOLS_LIST.length} Tools
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1">
              {CATEGORIES.map((cat) => {
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id as ToolCategory | 'all')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-[#FF6B00] text-white shadow-sm shadow-orange-500/30'
                        : 'bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:border-orange-200'
                    }`}
                  >
                    <span>{cat.labelEn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Show Category Specific View if selected != all */}
          {selectedCategory !== 'all' ? (
            <div className="px-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 capitalize">
                  {CATEGORIES.find((c) => c.id === selectedCategory)?.labelEn}
                </h2>
                <button
                  onClick={() => setSelectedCategory('all')}
                  className="text-xs text-[#FF6B00] font-semibold hover:underline"
                >
                  Show All
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredTools.map((tool) => (
                  <ToolCard key={tool.id} tool={tool} />
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* Recent Files Section (Processed files saved in localStorage) */}
              <RecentFilesSection />

              {/* Recently Used Tools (if user has opened any) */}
              {recentTools.length > 0 && (
                <div className="px-4">
                  <div className="flex items-center justify-between mb-2.5">
                    <div className="flex items-center gap-1.5">
                      <History className="w-4 h-4 text-[#FF8A00]" />
                      <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
                        {t('recentlyUsed')}
                      </h2>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    {recentTools.map((tool) => (
                      <ToolCard key={`recent-${tool.id}`} tool={tool} />
                    ))}
                  </div>
                </div>
              )}

              {/* Popular Tools */}
              <div className="px-4">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-[#FF6B00] fill-[#FF6B00]" />
                    <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
                      {t('popularTools')}
                    </h2>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {popularTools.map((tool) => (
                    <ToolCard key={tool.id} tool={tool} featured />
                  ))}
                </div>
              </div>

              {/* Daily Utilities Section */}
              <div className="px-4">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                    <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
                      {t('dailyTools')}
                    </h2>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {dailyTools.map((tool) => (
                    <ToolCard key={`daily-${tool.id}`} tool={tool} />
                  ))}
                </div>
              </div>

              {/* Explore All Tools Grid */}
              <div className="px-4 pt-2">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
                    {t('exploreTools')} ({ALL_TOOLS_LIST.length})
                  </h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {ALL_TOOLS_LIST.map((tool) => (
                    <ToolCard key={`all-${tool.id}`} tool={tool} />
                  ))}
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};
