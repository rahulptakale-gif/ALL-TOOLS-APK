import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const zip = new JSZip();

function addDirectoryToZip(dirPath, currentZipFolder) {
  const entries = fs.readdirSync(dirPath);
  for (const entry of entries) {
    if (entry === 'node_modules' || entry === '.git' || entry === '.cache' || entry.endsWith('.zip')) {
      continue;
    }
    const fullPath = path.join(dirPath, entry);
    try {
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        const subFolder = currentZipFolder.folder(entry);
        addDirectoryToZip(fullPath, subFolder);
      } else {
        currentZipFolder.file(entry, fs.readFileSync(fullPath));
      }
    } catch (err) {
      console.warn('Skipping file:', fullPath, err.message);
    }
  }
}

console.log('Archiving project directory into ZIP...');
addDirectoryToZip(rootDir, zip);

const outputPath = path.join(rootDir, 'dist', 'ALL_TOOLS_Android_Studio_Project.zip');
zip.generateAsync({
  type: 'nodebuffer',
  compression: 'DEFLATE',
  compressionOptions: { level: 6 },
}).then((buffer) => {
  fs.writeFileSync(outputPath, buffer);
  console.log(`Successfully generated: ${outputPath} (${(buffer.length / (1024 * 1024)).toFixed(2)} MB)`);
}).catch((err) => {
  console.error('Error creating ZIP:', err);
  process.exit(1);
});
