import React from 'react';
import { useApp } from '../../context/AppContext';
import { Clock, Trash2, ArrowUpRight, FileCheck } from 'lucide-react';
import { ALL_TOOLS_LIST } from '../../data/tools';

export const HistoryView: React.FC = () => {
  const { history, clearHistory, openTool, t } = useApp();

  const handleClear = () => {
    if (window.confirm(t('clearHistoryConfirm'))) {
      clearHistory();
    }
  };

  const formatTime = (ts: number) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="px-4 py-4 pb-24 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
            {t('history')}
          </h1>
          <p className="text-xs text-neutral-500">
            {history.length} recent operations logged on this device
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={handleClear}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t('clearHistory')}</span>
          </button>
        )}
      </div>

      {history.length > 0 ? (
        <div className="space-y-2.5">
          {history.map((item) => {
            const tool = ALL_TOOLS_LIST.find((t) => t.id === item.toolId);
            return (
              <div
                key={item.id}
                onClick={() => openTool(item.toolId)}
                className="bg-white dark:bg-[#1E1F24] border border-orange-100/80 dark:border-neutral-800 rounded-2xl p-3.5 flex items-center justify-between gap-3 hover:border-orange-300 dark:hover:border-neutral-700 transition-all cursor-pointer group active:scale-[0.99]"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] flex items-center justify-center shrink-0 mt-0.5">
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-xs text-neutral-900 dark:text-neutral-100 truncate group-hover:text-[#FF6B00] transition-colors">
                        {tool ? tool.name : item.toolName}
                      </h4>
                      <span className="text-[10px] text-neutral-400 shrink-0">
                        {formatTime(item.timestamp)}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate mt-0.5">
                      {item.actionSummary}
                    </p>
                    {item.fileName && (
                      <span className="inline-block mt-1 text-[10px] text-neutral-600 dark:text-neutral-400 font-mono truncate max-w-[200px]">
                        📄 {item.fileName}
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-neutral-400 group-hover:text-[#FF6B00] transition-colors shrink-0">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-16 px-4 bg-white dark:bg-[#1E1F24] rounded-3xl border border-orange-100 dark:border-neutral-800">
          <div className="w-14 h-14 rounded-2xl bg-orange-50 dark:bg-orange-950/40 text-[#FF6B00] flex items-center justify-center mx-auto mb-3">
            <Clock className="w-7 h-7 stroke-[1.5]" />
          </div>
          <h3 className="font-bold text-sm text-neutral-800 dark:text-neutral-200">
            {t('noHistory')}
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
            {t('noHistoryDesc')}
          </p>
        </div>
      )}
    </div>
  );
};
