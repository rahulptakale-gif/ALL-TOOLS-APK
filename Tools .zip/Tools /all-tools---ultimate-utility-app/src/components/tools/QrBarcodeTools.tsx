import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import confetti from 'canvas-confetti';
import {
  QrCode,
  Scan,
  Download,
  Copy,
  Check,
  Share2,
  Wifi,
  Globe,
  MessageSquare,
  IndianRupee,
  Camera,
  Upload,
  Barcode,
  Sparkles,
} from 'lucide-react';

interface QrBarcodeToolsProps {
  toolId: string;
}

export const QrBarcodeTools: React.FC<QrBarcodeToolsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();
  const [qrType, setQrType] = useState<'text' | 'url' | 'wifi' | 'upi' | 'whatsapp'>('url');

  // Input states
  const [textValue, setTextValue] = useState<string>('https://google.com');
  const [wifiSsid, setWifiSsid] = useState<string>('Shop_WiFi_5G');
  const [wifiPass, setWifiPass] = useState<string>('');
  const [wifiAuth, setWifiAuth] = useState<'WPA' | 'WEP' | 'nopass'>('WPA');

  // UPI Payment State
  const [upiId, setUpiId] = useState<string>('rahul@upi');
  const [upiName, setUpiName] = useState<string>('CSC Digital Services');
  const [upiAmount, setUpiAmount] = useState<string>('');

  // WhatsApp
  const [waPhone, setWaPhone] = useState<string>('919876543210');
  const [waMessage, setWaMessage] = useState<string>('Hello, I need help with document services.');

  // QR Color
  const [qrColor, setQrColor] = useState<string>('#FF6B00');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Barcode state
  const [barcodeValue, setBarcodeValue] = useState<string>('8901030925431');
  const [barcodeDataUrl, setBarcodeDataUrl] = useState<string>('');

  // Scanner state
  const [scannedResult, setScannedResult] = useState<string | null>(null);
  const [scannerCamera, setScannerCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Generate QR string based on selected type
  const getPayloadString = (): string => {
    if (qrType === 'url') {
      return textValue.startsWith('http') ? textValue : `https://${textValue}`;
    }
    if (qrType === 'wifi') {
      return `WIFI:S:${wifiSsid};T:${wifiAuth};P:${wifiPass};;`;
    }
    if (qrType === 'upi') {
      let upi = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(upiName)}`;
      if (upiAmount) upi += `&am=${encodeURIComponent(upiAmount)}&cu=INR`;
      return upi;
    }
    if (qrType === 'whatsapp') {
      const cleanPhone = waPhone.replace(/\D/g, '');
      return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(waMessage)}`;
    }
    return textValue;
  };

  // Re-generate QR
  useEffect(() => {
    if (toolId === 'qr-generator' || toolId === 'text-to-qr') {
      const payload = getPayloadString();
      if (!payload) return;
      QRCode.toDataURL(
        payload,
        {
          width: 400,
          margin: 2,
          color: {
            dark: qrColor,
            light: '#FFFFFF',
          },
        },
        (err, url) => {
          if (!err && url) {
            setQrDataUrl(url);
          }
        }
      );
    }
  }, [qrType, textValue, wifiSsid, wifiPass, wifiAuth, upiId, upiName, upiAmount, waPhone, waMessage, qrColor, toolId]);

  // Generate Barcode using Canvas (Standard Code 128 / Code 39 pattern)
  useEffect(() => {
    if (toolId === 'barcode-generator') {
      const canvas = document.createElement('canvas');
      canvas.width = 400;
      canvas.height = 140;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#111827';
      // Draw standard barcode pattern lines
      const code = barcodeValue || '1234567890';
      let x = 40;
      const barHeight = 80;

      for (let i = 0; i < code.length; i++) {
        const charCode = code.charCodeAt(i);
        const w1 = ((charCode % 3) + 1) * 2;
        const w2 = (((charCode >> 1) % 2) + 1) * 2;
        const w3 = (((charCode >> 2) % 3) + 1) * 2;

        ctx.fillRect(x, 15, w1, barHeight);
        x += w1 + 3;
        ctx.fillRect(x, 15, w2, barHeight);
        x += w2 + 2;
        ctx.fillRect(x, 15, w3, barHeight);
        x += w3 + 3;
      }

      ctx.font = 'bold 16px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(code, canvas.width / 2, barHeight + 40);

      setBarcodeDataUrl(canvas.toDataURL('image/png'));
    }
  }, [barcodeValue, toolId]);

  const handleCopyPayload = () => {
    const payload = getPayloadString();
    navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const [scanError, setScanError] = useState<string | null>(null);
  const scanLoopRef = useRef<number | null>(null);

  // Stop camera stream
  const stopCamera = () => {
    if (scanLoopRef.current) {
      cancelAnimationFrame(scanLoopRef.current);
      scanLoopRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setScannerCamera(false);
  };

  // Start real live camera scanner
  const startCameraScanner = async () => {
    try {
      setScanError(null);
      setScannedResult(null);
      setScannerCamera(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        scanLoopRef.current = requestAnimationFrame(scanCameraFrame);
      }
    } catch (err: any) {
      setScanError('Camera access denied or unavailable: ' + err.message);
      setScannerCamera(false);
    }
  };

  // Camera frame scanning loop using jsQR
  const scanCameraFrame = () => {
    if (!videoRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      scanLoopRef.current = requestAnimationFrame(scanCameraFrame);
      return;
    }
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert',
    });

    if (code && code.data) {
      setScannedResult(code.data);
      addToHistory(toolId, 'Scanned Live QR Code');
      confetti({ particleCount: 40, spread: 60 });
      stopCamera();
    } else {
      scanLoopRef.current = requestAnimationFrame(scanCameraFrame);
    }
  };

  // Clean up camera on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Handle Real Scan from uploaded image file
  const handleScanUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setScanError(null);
      setScannedResult(null);

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'attemptBoth',
        });

        if (code && code.data) {
          setScannedResult(code.data);
          addToHistory(toolId, 'Scanned QR Code from Image', file.name);
          confetti({ particleCount: 40, spread: 60 });
        } else {
          setScanError('No readable QR code found in this image. Please ensure the QR is sharp and well-lit.');
        }
      };
      img.onerror = () => {
        setScanError('Unable to load image file for decoding.');
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="space-y-4">
      {/* 1. QR Code Generator */}
      {(toolId === 'qr-generator' || toolId === 'text-to-qr') && (
        <div className="space-y-4">
          {/* QR Category Tabs */}
          <div className="grid grid-cols-5 gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-2xl text-[11px] font-bold">
            {[
              { id: 'url', label: 'URL', icon: Globe },
              { id: 'upi', label: 'UPI Pay', icon: IndianRupee },
              { id: 'wifi', label: 'Wi-Fi', icon: Wifi },
              { id: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
              { id: 'text', label: 'Text', icon: Sparkles },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = qrType === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setQrType(tab.id as any)}
                  className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                    isActive
                      ? 'bg-white dark:bg-[#1E1F24] text-[#FF6B00] shadow-sm'
                      : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Form Inputs based on active QR type */}
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3">
            {qrType === 'url' && (
              <div>
                <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Website URL
                </label>
                <input
                  type="text"
                  value={textValue}
                  onChange={(e) => setTextValue(e.target.value)}
                  placeholder="https://example.com"
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                />
              </div>
            )}

            {qrType === 'upi' && (
              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    UPI VPA / ID
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="e.g. shopname@okaxis"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                      Payee Name
                    </label>
                    <input
                      type="text"
                      value={upiName}
                      onChange={(e) => setUpiName(e.target.value)}
                      placeholder="e.g. CSC Store"
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                      Amount ₹ (Optional)
                    </label>
                    <input
                      type="number"
                      value={upiAmount}
                      onChange={(e) => setUpiAmount(e.target.value)}
                      placeholder="e.g. 50"
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {qrType === 'wifi' && (
              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Network Name (SSID)
                  </label>
                  <input
                    type="text"
                    value={wifiSsid}
                    onChange={(e) => setWifiSsid(e.target.value)}
                    placeholder="Wi-Fi Name"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Wi-Fi Password
                  </label>
                  <input
                    type="text"
                    value={wifiPass}
                    onChange={(e) => setWifiPass(e.target.value)}
                    placeholder="Enter password"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                </div>
              </div>
            )}

            {qrType === 'whatsapp' && (
              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    WhatsApp Mobile Number (With Country Code)
                  </label>
                  <input
                    type="text"
                    value={waPhone}
                    onChange={(e) => setWaPhone(e.target.value)}
                    placeholder="e.g. 919876543210"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Prefilled Message
                  </label>
                  <textarea
                    rows={2}
                    value={waMessage}
                    onChange={(e) => setWaMessage(e.target.value)}
                    className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                </div>
              </div>
            )}

            {qrType === 'text' && (
              <div>
                <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                  Plain Text Content
                </label>
                <textarea
                  rows={3}
                  value={textValue}
                  onChange={(e) => setTextValue(e.target.value)}
                  placeholder="Enter any text, notice or contact info"
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                />
              </div>
            )}

            {/* Color Selector */}
            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-600 dark:text-neutral-400">QR Code Color</span>
              <div className="flex gap-2">
                {[
                  { color: '#FF6B00', name: 'Bright Orange' },
                  { color: '#202124', name: 'Classic Black' },
                  { color: '#1E40AF', name: 'Navy Blue' },
                  { color: '#047857', name: 'Emerald' },
                ].map((c) => (
                  <button
                    key={c.color}
                    onClick={() => setQrColor(c.color)}
                    style={{ backgroundColor: c.color }}
                    className={`w-6 h-6 rounded-full border-2 transition-transform ${
                      qrColor === c.color ? 'scale-125 border-white shadow-md ring-2 ring-[#FF6B00]' : 'border-transparent'
                    }`}
                    title={c.name}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* QR Display Card */}
          {qrDataUrl && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm">
              <div className="w-52 h-52 mx-auto p-3 rounded-2xl bg-white border border-neutral-200 dark:border-neutral-700 shadow-sm flex items-center justify-center">
                <img src={qrDataUrl} alt="Generated QR" className="w-full h-full object-contain" />
              </div>

              <div className="flex gap-2">
                <a
                  href={qrDataUrl}
                  download={`QRCode_${qrType}_${Date.now()}.png`}
                  className="flex-1 py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download QR PNG</span>
                </a>
                <button
                  onClick={handleCopyPayload}
                  className="px-4 py-3 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-xl hover:bg-neutral-200 flex items-center gap-1.5"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. Barcode Generator */}
      {toolId === 'barcode-generator' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-4 space-y-3">
            <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
              Barcode Digits / Text
            </label>
            <input
              type="text"
              value={barcodeValue}
              onChange={(e) => setBarcodeValue(e.target.value)}
              placeholder="e.g. 8901030925431"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-mono"
            />
            <span className="text-[10px] text-neutral-400 block">
              Generates high-contrast Code 128 standard product / item barcode.
            </span>
          </div>

          {barcodeDataUrl && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm">
              <div className="max-w-xs mx-auto p-4 rounded-2xl bg-white border border-neutral-200 dark:border-neutral-700">
                <img src={barcodeDataUrl} alt="Barcode" className="w-full object-contain" />
              </div>
              <a
                href={barcodeDataUrl}
                download={`Barcode_${barcodeValue}.png`}
                className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 inline-flex"
              >
                <Download className="w-4 h-4" />
                <span>Download Barcode Image</span>
              </a>
            </div>
          )}
        </div>
      )}

      {/* 3. QR & Barcode Scanner */}
      {toolId === 'qr-scanner' && (
        <div className="space-y-4">
          {/* Camera Viewfinder (if camera is active) */}
          {scannerCamera ? (
            <div className="relative rounded-3xl overflow-hidden bg-black aspect-[4/3] flex flex-col items-center justify-center border-2 border-[#FF6B00] shadow-lg">
              <video ref={videoRef} playsInline className="w-full h-full object-cover" />
              {/* Animated scanner overlay box */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-48 h-48 border-2 border-[#FF6B00] rounded-2xl relative animate-pulse shadow-[0_0_20px_rgba(255,107,0,0.5)]">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-white" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-white" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-white" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-white" />
                  <div className="w-full h-0.5 bg-[#FF6B00] absolute top-1/2 -translate-y-1/2 animate-bounce" />
                </div>
              </div>
              <div className="absolute bottom-4 flex items-center gap-3">
                <button
                  type="button"
                  onClick={stopCamera}
                  className="px-4 py-2 bg-neutral-900/80 backdrop-blur-md text-white font-bold text-xs rounded-full hover:bg-neutral-800 transition-colors"
                >
                  Stop Camera
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <button
                type="button"
                onClick={startCameraScanner}
                className="w-full py-3.5 bg-gradient-to-r from-[#FF6B00] to-[#FF8A00] hover:from-[#E65100] hover:to-[#FF6B00] text-white font-bold text-xs rounded-2xl shadow-md shadow-orange-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
              >
                <Camera className="w-4 h-4" />
                <span>Start Live Camera QR Scanner</span>
              </button>

              <div className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleScanUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm">
                  <Scan className="w-6 h-6 stroke-[2]" />
                </div>
                <h3 className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
                  Or Upload QR / Barcode Image
                </h3>
                <p className="text-[11px] text-neutral-500 mt-1">
                  Select screenshot, photo or document containing a QR code
                </p>
              </div>
            </div>
          )}

          {scanError && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-2xl text-xs font-medium border border-red-200 dark:border-red-800">
              {scanError}
            </div>
          )}

          {scannedResult && (
            <div className="bg-white dark:bg-[#1E1F24] border border-emerald-200 dark:border-emerald-800 rounded-3xl p-5 space-y-3 shadow-sm animate-scale-up">
              <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
                <Sparkles className="w-4 h-4" />
                <span>Successfully Decoded Real QR Content</span>
              </div>
              <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded-2xl font-mono text-xs text-neutral-800 dark:text-neutral-200 break-all select-text border border-neutral-200 dark:border-neutral-700">
                {scannedResult}
              </div>
              <div className="flex flex-wrap gap-2">
                {scannedResult.startsWith('http://') || scannedResult.startsWith('https://') ? (
                  <a
                    href={scannedResult}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 bg-[#FF6B00] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Open Link in Browser</span>
                  </a>
                ) : null}
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(scannedResult);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="flex-1 py-2.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-800 dark:text-neutral-200 font-bold text-xs rounded-xl flex items-center justify-center gap-2"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Content'}</span>
                </button>
                <button
                  onClick={() => {
                    setScannedResult(null);
                    setScanError(null);
                  }}
                  className="py-2.5 px-4 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-xl"
                >
                  Clear
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
