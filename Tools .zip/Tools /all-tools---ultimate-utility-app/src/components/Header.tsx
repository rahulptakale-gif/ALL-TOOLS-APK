import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sun, Moon, Globe, Shield, Sparkles, Check, Download } from 'lucide-react';
import { Language } from '../types';

export const Header: React.FC = () => {
  const { theme, setTheme, language, setLanguage, t } = useApp();
  const [showLangMenu, setShowLangMenu] = useState(false);

  const languages: { code: Language; name: string; native: string }[] = [
    { code: 'en', name: 'English', native: 'English' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
    { code: 'mr', name: 'Marathi', native: 'मराठी' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#1A1B20]/95 backdrop-blur-md border-b border-orange-100 dark:border-neutral-800 transition-colors">
      <div className="px-4 py-3 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF6B00] via-[#FF8A00] to-[#FFA726] flex items-center justify-center shadow-md shadow-orange-500/20 text-white font-black text-xl tracking-tighter">
            <Sparkles className="w-5 h-5 fill-white text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-[#FF6B00] to-[#E65100] dark:from-[#FF8A00] dark:to-[#FFA726] bg-clip-text text-transparent">
                ALL TOOLS
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-orange-100 text-[#FF6B00] dark:bg-orange-950/70 dark:text-orange-300">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 font-medium -mt-0.5 truncate max-w-[190px]">
              {t('tagline')}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1">
          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="p-2 rounded-xl text-neutral-700 dark:text-neutral-200 hover:bg-orange-50 dark:hover:bg-neutral-800 transition-colors flex items-center gap-1 text-xs font-semibold"
              title="Change Language"
              aria-label="Language"
            >
              <Globe className="w-4 h-4 text-[#FF6B00]" />
              <span className="uppercase text-[11px] font-bold tracking-wider">
                {language}
              </span>
            </button>

            {showLangMenu && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowLangMenu(false)}
                />
                <div className="absolute right-0 mt-2 w-44 rounded-2xl bg-white dark:bg-[#202126] border border-orange-100 dark:border-neutral-700 shadow-xl z-50 p-1.5 overflow-hidden">
                  <div className="px-2.5 py-1.5 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                    Select Language
                  </div>
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setShowLangMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-xl font-medium transition-colors ${
                        language === l.code
                          ? 'bg-orange-50 text-[#FF6B00] dark:bg-orange-950/40 dark:text-orange-300 font-bold'
                          : 'text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <span>{l.native}</span>
                      {language === l.code && <Check className="w-3.5 h-3.5 text-[#FF6B00]" />}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Export Android Project ZIP Button */}
          <a
            href="/api/export-project-zip"
            download="ALL_TOOLS_Android_Studio_Project.zip"
            className="p-2 rounded-xl text-[#FF6B00] hover:bg-orange-50 dark:hover:bg-neutral-800 transition-colors flex items-center gap-1 text-xs font-bold"
            title="Download Complete Android Studio Project (.ZIP)"
            aria-label="Export Android Project"
          >
            <Download className="w-4 h-4 stroke-[2.2]" />
            <span className="hidden sm:inline text-[11px]">APK Project</span>
          </a>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2 rounded-xl text-neutral-700 dark:text-neutral-200 hover:bg-orange-50 dark:hover:bg-neutral-800 transition-colors"
            title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-neutral-600" />
            )}
          </button>
        </div>
      </div>

      {/* CSC & Privacy Sub-bar */}
      <div className="bg-[#FFF8F2] dark:bg-[#1E1914] px-4 py-1.5 border-t border-orange-100/60 dark:border-neutral-800 flex items-center justify-between text-[11px] text-[#A74100] dark:text-orange-300">
        <div className="flex items-center gap-1.5 font-medium">
          <Shield className="w-3.5 h-3.5 text-[#FF6B00] shrink-0" />
          <span className="truncate">100% On-Device Processing · Zero Cloud Uploads</span>
        </div>
        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-white dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 shrink-0 border border-orange-200 dark:border-neutral-700">
          CSC Ready
        </span>
      </div>
    </header>
  );
};
