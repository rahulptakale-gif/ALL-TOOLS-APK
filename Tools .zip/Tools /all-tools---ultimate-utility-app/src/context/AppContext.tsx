import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppState, HistoryItem, Language, RecentProcessedFile, ToolCategory, ToolItem } from '../types';
import { UI_STRINGS } from '../translations';
import { ALL_TOOLS_LIST } from '../data/tools';

interface AppContextType extends AppState {
  setLanguage: (lang: Language) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setAccentColor: (color: string) => void;
  setActiveTab: (tab: 'home' | 'favorites' | 'history' | 'settings') => void;
  setSelectedCategory: (cat: ToolCategory | 'all') => void;
  setSearchQuery: (query: string) => void;
  openTool: (toolId: string) => void;
  closeTool: () => void;
  toggleFavorite: (toolId: string) => void;
  isFavorite: (toolId: string) => boolean;
  addToHistory: (toolId: string, actionSummary: string, fileName?: string) => void;
  clearHistory: () => void;
  addRecentFile: (file: Omit<RecentProcessedFile, 'id' | 'timestamp'> & { timestamp?: number }) => void;
  clearRecentFiles: () => void;
  t: (key: string) => string;
  getToolName: (tool: ToolItem) => string;
  getToolDesc: (tool: ToolItem) => string;
  activeTool: ToolItem | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEYS = {
  THEME: 'alltools_theme',
  LANG: 'alltools_lang',
  ACCENT: 'alltools_accent',
  FAVORITES: 'alltools_favorites',
  HISTORY: 'alltools_history',
  RECENT_FILES: 'alltools_recent_files',
};

const DEFAULT_FAVORITES = ['csc-aadhaar', 'csc-pan', 'img-compressor', 'pdf-merger', 'qr-generator', 'calc-age'];

const DEFAULT_RECENT_FILES: RecentProcessedFile[] = [
  {
    id: 'rf-1',
    fileName: 'e-Aadhaar_A4_Xerox.pdf',
    toolId: 'csc-aadhaar',
    toolName: 'Aadhaar Document PDF Utilities',
    timestamp: Date.now() - 1000 * 60 * 45,
    actionSummary: 'Masked Aadhaar & 2-side A4 layout created',
    sizeKb: 142,
    category: 'csc',
  },
  {
    id: 'rf-2',
    fileName: 'Passport_8_Photo_Sheet.jpg',
    toolId: 'img-passport',
    toolName: 'Passport Size Photo Maker',
    timestamp: Date.now() - 1000 * 60 * 60 * 3,
    actionSummary: 'Generated 8 photo 4x6 inch studio sheet',
    sizeKb: 380,
    category: 'image',
  },
  {
    id: 'rf-3',
    fileName: 'Merged_Application_Docs.pdf',
    toolId: 'pdf-merger',
    toolName: 'PDF Merger',
    timestamp: Date.now() - 1000 * 60 * 60 * 22,
    actionSummary: 'Merged 3 documents into single PDF',
    sizeKb: 615,
    category: 'pdf',
  },
];

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.THEME);
    return saved === 'dark' ? 'dark' : 'light';
  });

  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.LANG) as Language;
    return saved && ['en', 'hi', 'mr'].includes(saved) ? saved : 'en';
  });

  const [accentColor, setAccentColorState] = useState<string>(() => {
    return localStorage.getItem(LOCAL_STORAGE_KEYS.ACCENT) || '#FF6B00';
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.FAVORITES);
      return saved ? JSON.parse(saved) : DEFAULT_FAVORITES;
    } catch {
      return DEFAULT_FAVORITES;
    }
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.HISTORY);
      return saved ? JSON.parse(saved) : [
        {
          id: 'demo-1',
          toolId: 'csc-aadhaar',
          toolName: 'Aadhaar Card PDF Utilities',
          timestamp: Date.now() - 3600000 * 2,
          actionSummary: 'Masked 8 digits & prepared A4 Xerox print',
          fileName: 'e-Aadhaar_doc.pdf',
        },
        {
          id: 'demo-2',
          toolId: 'img-compressor',
          toolName: 'Image Compressor (Target KB)',
          timestamp: Date.now() - 3600000 * 5,
          actionSummary: 'Compressed 2.4 MB to 45 KB for SSC form',
          fileName: 'passport_pic.jpg',
        },
      ];
    } catch {
      return [];
    }
  });

  const [recentFiles, setRecentFiles] = useState<RecentProcessedFile[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.RECENT_FILES);
      return saved ? JSON.parse(saved) : DEFAULT_RECENT_FILES;
    } catch {
      return DEFAULT_RECENT_FILES;
    }
  });

  const [activeTab, setActiveTab] = useState<'home' | 'favorites' | 'history' | 'settings'>('home');
  const [selectedCategory, setSelectedCategory] = useState<ToolCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeToolId, setActiveToolId] = useState<string | null>(null);

  // Sync theme to document class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(LOCAL_STORAGE_KEYS.THEME, theme);
  }, [theme]);

  const setTheme = (newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(LOCAL_STORAGE_KEYS.LANG, lang);
  };

  const setAccentColor = (color: string) => {
    setAccentColorState(color);
    localStorage.setItem(LOCAL_STORAGE_KEYS.ACCENT, color);
  };

  const toggleFavorite = (toolId: string) => {
    setFavorites((prev) => {
      const next = prev.includes(toolId) ? prev.filter((id) => id !== toolId) : [...prev, toolId];
      localStorage.setItem(LOCAL_STORAGE_KEYS.FAVORITES, JSON.stringify(next));
      return next;
    });
  };

  const isFavorite = (toolId: string) => favorites.includes(toolId);

  const addRecentFile = (file: Omit<RecentProcessedFile, 'id' | 'timestamp'> & { timestamp?: number }) => {
    const newItem: RecentProcessedFile = {
      id: `rf-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: file.timestamp || Date.now(),
      ...file,
    };
    setRecentFiles((prev) => {
      const filtered = prev.filter((item) => item.fileName !== file.fileName);
      const next = [newItem, ...filtered].slice(0, 30);
      localStorage.setItem(LOCAL_STORAGE_KEYS.RECENT_FILES, JSON.stringify(next));
      return next;
    });
  };

  const clearRecentFiles = () => {
    setRecentFiles([]);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.RECENT_FILES);
  };

  const addToHistory = (toolId: string, actionSummary: string, fileName?: string) => {
    const tool = ALL_TOOLS_LIST.find((t) => t.id === toolId);
    const newItem: HistoryItem = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      toolId,
      toolName: tool ? tool.name : toolId,
      timestamp: Date.now(),
      fileName,
      actionSummary,
    };
    setHistory((prev) => {
      const filtered = prev.filter((item) => !(item.toolId === toolId && item.fileName === fileName));
      const next = [newItem, ...filtered].slice(0, 50);
      localStorage.setItem(LOCAL_STORAGE_KEYS.HISTORY, JSON.stringify(next));
      return next;
    });

    // If a file was processed, also persist to recentFiles in localStorage
    if (fileName) {
      const newRecentFile: RecentProcessedFile = {
        id: `rf-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        fileName,
        toolId,
        toolName: tool ? tool.name : toolId,
        timestamp: Date.now(),
        actionSummary,
        category: tool?.category,
      };
      setRecentFiles((prev) => {
        const filtered = prev.filter((item) => item.fileName !== fileName);
        const next = [newRecentFile, ...filtered].slice(0, 30);
        localStorage.setItem(LOCAL_STORAGE_KEYS.RECENT_FILES, JSON.stringify(next));
        return next;
      });
    }
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.HISTORY);
  };

  const openTool = (toolId: string) => {
    setActiveToolId(toolId);
    const tool = ALL_TOOLS_LIST.find((t) => t.id === toolId);
    if (tool) {
      addToHistory(tool.id, 'Opened tool');
    }
  };

  const closeTool = () => {
    setActiveToolId(null);
  };

  const t = (key: string): string => {
    return UI_STRINGS[language]?.[key] || UI_STRINGS.en[key] || key;
  };

  const getToolName = (tool: ToolItem): string => {
    if (language === 'hi' && tool.nameHi) return tool.nameHi;
    if (language === 'mr' && tool.nameMr) return tool.nameMr;
    return tool.name;
  };

  const getToolDesc = (tool: ToolItem): string => {
    if (language === 'hi' && tool.descriptionHi) return tool.descriptionHi;
    if (language === 'mr' && tool.descriptionMr) return tool.descriptionMr;
    return tool.description;
  };

  const activeTool = activeToolId ? ALL_TOOLS_LIST.find((t) => t.id === activeToolId) || null : null;

  return (
    <AppContext.Provider
      value={{
        theme,
        language,
        accentColor,
        favorites,
        history,
        recentFiles,
        activeTab,
        selectedCategory,
        activeToolId,
        searchQuery,
        activeTool,
        setLanguage,
        setTheme,
        setAccentColor,
        setActiveTab,
        setSelectedCategory,
        setSearchQuery,
        openTool,
        closeTool,
        toggleFavorite,
        isFavorite,
        addToHistory,
        clearHistory,
        addRecentFile,
        clearRecentFiles,
        t,
        getToolName,
        getToolDesc,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
