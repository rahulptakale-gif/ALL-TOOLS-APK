import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { PDFDocument } from 'pdf-lib';
import confetti from 'canvas-confetti';
import {
  FilePlus2,
  Upload,
  Download,
  Trash2,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  FileText,
  Eye,
  EyeOff,
  Share2,
  Layers,
  AlertCircle,
} from 'lucide-react';

interface PdfFileItem {
  id: string;
  file: File;
  name: string;
  size: number;
  pageCount?: number;
}

export const PdfMergeTool: React.FC = () => {
  const { addToHistory, t } = useApp();
  const [pdfList, setPdfList] = useState<PdfFileItem[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultFileName, setResultFileName] = useState<string>(
    `Merged_Document_${new Date().toISOString().slice(0, 10)}.pdf`
  );
  const [resultStats, setResultStats] = useState<{ totalPages: number; sizeKb: number } | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Read page count for uploaded files asynchronously
  const readPageCount = async (file: File): Promise<number | undefined> => {
    try {
      const buffer = await file.arrayBuffer();
      const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
      return doc.getPageCount();
    } catch {
      return undefined;
    }
  };

  const handleFilesAdded = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setError(null);

    const newItems: PdfFileItem[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
        newItems.push({
          id: `${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          file,
          name: file.name,
          size: file.size,
        });
      }
    }

    if (newItems.length === 0) {
      setError('Please select valid PDF documents.');
      return;
    }

    // Append to list
    setPdfList((prev) => [...prev, ...newItems]);

    // Asynchronously resolve page counts for the new items
    for (const item of newItems) {
      const count = await readPageCount(item.file);
      setPdfList((prev) =>
        prev.map((p) => (p.id === item.id ? { ...p, pageCount: count } : p))
      );
    }
  };

  // Reorder items
  const moveUp = (index: number) => {
    if (index <= 0) return;
    setPdfList((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index - 1];
      updated[index - 1] = temp;
      return updated;
    });
  };

  const moveDown = (index: number) => {
    if (index >= pdfList.length - 1) return;
    setPdfList((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index + 1];
      updated[index + 1] = temp;
      return updated;
    });
  };

  const removeItem = (id: string) => {
    setPdfList((prev) => prev.filter((item) => item.id !== id));
  };

  const clearAll = () => {
    setPdfList([]);
    setResultUrl(null);
    setResultStats(null);
    setError(null);
    setProgress(0);
  };

  // Perform PDF Merge using pdf-lib
  const handleMergePdfs = async () => {
    if (pdfList.length < 2) {
      setError('Please select at least 2 PDF files to merge.');
      return;
    }

    try {
      setProcessing(true);
      setError(null);
      setProgress(5);
      setStatusMessage('Initializing new PDF document...');

      // 1. Create a fresh PDF document
      const mergedPdf = await PDFDocument.create();

      // Set document metadata
      mergedPdf.setTitle(resultFileName.replace(/\.pdf$/i, ''));
      mergedPdf.setProducer('ALL TOOLS Utility Engine (pdf-lib)');
      mergedPdf.setCreationDate(new Date());

      let totalPagesAdded = 0;

      // 2. Iterate through each PDF in user's custom sequence
      for (let i = 0; i < pdfList.length; i++) {
        const item = pdfList[i];
        const stepProgress = 10 + Math.round((i / pdfList.length) * 75);
        setProgress(stepProgress);
        setStatusMessage(`Copying pages from ${item.name} (${i + 1} of ${pdfList.length})...`);

        const arrayBuffer = await item.file.arrayBuffer();
        const sourceDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
        const pageIndices = sourceDoc.getPageIndices();
        const copiedPages = await mergedPdf.copyPages(sourceDoc, pageIndices);

        copiedPages.forEach((page) => {
          mergedPdf.addPage(page);
          totalPagesAdded++;
        });
      }

      setProgress(90);
      setStatusMessage('Optimizing and compiling merged document...');

      // 3. Save the merged PDF bytes
      const mergedPdfBytes = await mergedPdf.save({ useObjectStreams: true });
      const blob = new Blob([mergedPdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setResultUrl(url);
      setResultStats({
        totalPages: totalPagesAdded,
        sizeKb: Math.round(blob.size / 1024),
      });

      addToHistory(
        'pdf-merger',
        `Merged ${pdfList.length} files (${totalPagesAdded} pages) into one PDF`,
        resultFileName
      );

      setProgress(100);
      setStatusMessage('Complete!');
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
    } catch (err: any) {
      console.error('PDF Merge Error:', err);
      setError(err.message || 'Failed to merge the selected PDF documents. One of the files may be corrupted or encrypted.');
    } finally {
      setProcessing(false);
    }
  };

  const handleShare = () => {
    if (resultUrl && navigator.share) {
      navigator.share({
        title: resultFileName,
        text: `Here is my merged PDF: ${resultFileName}`,
        url: resultUrl,
      }).catch(() => {});
    } else if (resultUrl) {
      navigator.clipboard.writeText(resultUrl);
      alert('Merged PDF link copied to clipboard!');
    }
  };

  const totalPagesSum = pdfList.reduce((acc, curr) => acc + (curr.pageCount || 0), 0);

  return (
    <div className="space-y-4">
      {/* Upload Zone */}
      {!resultUrl && (
        <div className="space-y-3">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors cursor-pointer group"
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,application/pdf"
              onChange={(e) => handleFilesAdded(e.target.files)}
              className="hidden"
            />
            <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm group-hover:scale-105 transition-transform">
              <Upload className="w-6 h-6 stroke-[2]" />
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-neutral-800 dark:text-neutral-200">
              {pdfList.length > 0 ? '+ Add More PDF Files' : t('dropFiles')}
            </h3>
            <p className="text-[11px] text-neutral-500 mt-1">
              Select 2 or more PDF documents to combine into a single file (100% on-device)
            </p>
          </div>

          {/* Selected Files Reorder List */}
          {pdfList.length > 0 && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-3xl p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
                <div>
                  <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
                    PDF Files ({pdfList.length})
                  </span>
                  {totalPagesSum > 0 && (
                    <span className="text-[11px] text-[#FF6B00] font-semibold ml-2">
                      · ~{totalPagesSum} Total Pages
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs font-bold text-[#FF6B00] hover:underline"
                  >
                    + Add More
                  </button>
                  <button
                    type="button"
                    onClick={clearAll}
                    className="text-xs font-bold text-red-500 hover:underline ml-2"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {pdfList.map((item, index) => (
                  <div
                    key={item.id}
                    className="p-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 rounded-2xl flex items-center justify-between gap-3 group transition-all"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-lg bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] font-bold text-xs flex items-center justify-center shrink-0">
                        #{index + 1}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-neutral-800 dark:text-neutral-200 truncate max-w-[180px] sm:max-w-xs">
                          {item.name}
                        </p>
                        <p className="text-[10px] text-neutral-400 mt-0.5">
                          {(item.size / 1024).toFixed(1)} KB
                          {item.pageCount !== undefined && ` · ${item.pageCount} ${item.pageCount === 1 ? 'page' : 'pages'}`}
                        </p>
                      </div>
                    </div>

                    {/* Up / Down Reorder and Delete controls */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => moveUp(index)}
                        disabled={index === 0}
                        className="p-1 rounded-lg text-neutral-400 hover:text-[#FF6B00] hover:bg-white dark:hover:bg-neutral-800 disabled:opacity-30 disabled:pointer-events-none"
                        title="Move Up"
                        aria-label="Move Up"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveDown(index)}
                        disabled={index === pdfList.length - 1}
                        className="p-1 rounded-lg text-neutral-400 hover:text-[#FF6B00] hover:bg-white dark:hover:bg-neutral-800 disabled:opacity-30 disabled:pointer-events-none"
                        title="Move Down"
                        aria-label="Move Down"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeItem(item.id)}
                        className="p-1 rounded-lg text-neutral-400 hover:text-red-500 hover:bg-white dark:hover:bg-neutral-800"
                        title="Remove file"
                        aria-label="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Output File Name Setting */}
              <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <label className="text-[11px] font-bold text-neutral-600 dark:text-neutral-400 block mb-1">
                  Merged PDF File Name
                </label>
                <input
                  type="text"
                  value={resultFileName}
                  onChange={(e) => setResultFileName(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs font-medium"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-2xl text-xs font-medium border border-red-200 dark:border-red-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Merge Trigger Button */}
          {pdfList.length > 0 && (
            <button
              onClick={handleMergePdfs}
              disabled={processing || pdfList.length < 2}
              className="w-full py-3.5 bg-gradient-to-r from-[#FF6B00] to-[#FF8A00] hover:from-[#E65100] hover:to-[#FF6B00] active:scale-[0.99] text-white font-bold text-sm rounded-2xl shadow-md shadow-orange-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Merging PDFs... ({progress}%)</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Merge {pdfList.length} PDF Files Now</span>
                </>
              )}
            </button>
          )}

          {/* Live Progress Bar when processing */}
          {processing && (
            <div className="p-3 bg-orange-50 dark:bg-orange-950/40 rounded-2xl border border-orange-200 dark:border-orange-900 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300">
                <span>{statusMessage}</span>
                <span className="text-[#FF6B00]">{progress}%</span>
              </div>
              <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-[#FF6B00] h-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Result Display & Download View */}
      {resultUrl && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm animate-scale-up">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
          </div>

          <div>
            <h3 className="font-extrabold text-base text-neutral-900 dark:text-neutral-100">
              PDFs Successfully Merged!
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5 font-mono truncate max-w-xs mx-auto">
              {resultFileName}
            </p>
          </div>

          {resultStats && (
            <div className="grid grid-cols-2 gap-2 max-w-xs mx-auto">
              <div className="p-2.5 bg-neutral-50 dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800">
                <span className="text-[10px] text-neutral-400 font-bold block uppercase">Total Pages</span>
                <span className="text-sm font-extrabold text-neutral-900 dark:text-neutral-100">
                  {resultStats.totalPages} Pages
                </span>
              </div>
              <div className="p-2.5 bg-neutral-50 dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800">
                <span className="text-[10px] text-neutral-400 font-bold block uppercase">Merged Size</span>
                <span className="text-sm font-extrabold text-[#FF6B00]">
                  {resultStats.sizeKb} KB
                </span>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col gap-2 pt-2">
            <a
              href={resultUrl}
              download={resultFileName}
              className="w-full py-3.5 bg-[#FF6B00] hover:bg-[#E65100] active:scale-[0.99] text-white font-bold text-xs rounded-2xl shadow-md shadow-orange-500/25 flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download Merged PDF</span>
            </a>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setShowPreview(!showPreview)}
                className="py-2.5 px-3 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-800 dark:text-neutral-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                {showPreview ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showPreview ? 'Hide Preview' : 'Preview PDF'}</span>
              </button>

              <button
                type="button"
                onClick={handleShare}
                className="py-2.5 px-3 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-800 dark:text-neutral-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share PDF</span>
              </button>
            </div>

            {/* Embedded PDF Viewer if preview toggled */}
            {showPreview && (
              <div className="mt-2 rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-700 bg-neutral-100 h-80">
                <iframe
                  src={resultUrl}
                  title="Merged PDF Preview"
                  className="w-full h-full border-0"
                />
              </div>
            )}

            <button
              onClick={clearAll}
              className="w-full py-2.5 text-neutral-500 hover:text-[#FF6B00] font-bold text-xs transition-colors mt-1"
            >
              Merge Another Batch of PDFs
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
