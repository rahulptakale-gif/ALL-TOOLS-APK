import React from 'react';
import { useApp } from '../context/AppContext';
import { Search, X, Sparkles } from 'lucide-react';

export const SearchBar: React.FC = () => {
  const { searchQuery, setSearchQuery, t } = useApp();

  return (
    <div className="relative px-4 py-2">
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-[#FF6B00] absolute left-3.5 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full pl-10 pr-10 py-2.5 bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-700/80 rounded-2xl text-xs sm:text-sm text-neutral-800 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF6B00] focus:border-transparent shadow-sm transition-all"
        />
        {searchQuery ? (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 p-1 rounded-full text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
            aria-label="Clear search"
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <span className="absolute right-3.5 flex items-center gap-1 text-[10px] text-neutral-400 uppercase font-semibold tracking-wider pointer-events-none">
            <Sparkles className="w-3 h-3 text-[#FF8A00]" />
          </span>
        )}
      </div>
    </div>
  );
};
