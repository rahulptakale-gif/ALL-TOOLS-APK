import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Gemini Multimodal OCR API endpoint (Hindi, Marathi, English, CSC docs)
app.post('/api/ocr', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', language = 'any' } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Image base64 data required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured in environment' });
    }

    const ai = new GoogleGenAI({ apiKey });
    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');

    let prompt = `Perform accurate Optical Character Recognition (OCR) on this document/image.
Extract all visible text cleanly and faithfully. Preserve structure, headings, table columns, and bullet points.
Support multilingual text including Hindi (Devanagari), Marathi, and English.
If this is an official identity card or certificate (Aadhaar, PAN Card, Voter ID, Driving Licence, Marksheet):
1. First list any key identifiable fields detected (e.g. Document Type, Name, Date of Birth / DOB, Document Number, Guardian Name, Address).
2. Followed by the complete raw recognized text.
Never invent any details. Return only the extracted content.`;

    if (language === 'hi') {
      prompt += '\nSpecial emphasis: Transcribe Hindi Devanagari characters accurately.';
    } else if (language === 'mr') {
      prompt += '\nSpecial emphasis: Transcribe Marathi Devanagari characters accurately.';
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: cleanBase64,
                mimeType,
              },
            },
          ],
        },
      ],
    });

    return res.json({ text: response.text || '' });
  } catch (err: any) {
    console.error('OCR Error:', err);
    return res.status(500).json({ error: err.message || 'OCR processing failed' });
  }
});

import fs from 'fs';
import JSZip from 'jszip';

// Helper to recursively add files into ZIP archive, ignoring node_modules & git
function addDirectoryToZip(zip: JSZip, dirPath: string, rootDir: string) {
  const entries = fs.readdirSync(dirPath);
  for (const entry of entries) {
    if (entry === 'node_modules' || entry === '.git' || entry === '.cache' || entry.endsWith('.zip')) {
      continue;
    }
    const fullPath = path.join(dirPath, entry);
    const relPath = path.relative(rootDir, fullPath);
    try {
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirectoryToZip(zip, fullPath, rootDir);
      } else {
        zip.file(relPath, fs.readFileSync(fullPath));
      }
    } catch {
      // Skip unreadable files
    }
  }
}

// Download Complete Android Studio Project ZIP
const sendProjectZip = async (_req: express.Request, res: express.Response) => {
  try {
    const prebuiltZipDist = path.join(__dirname, 'dist', 'ALL_TOOLS_Android_Studio_Project.zip');
    const prebuiltZipPublic = path.join(__dirname, 'public', 'ALL_TOOLS_Android_Studio_Project.zip');

    if (fs.existsSync(prebuiltZipDist)) {
      return res.download(prebuiltZipDist, 'ALL_TOOLS_Android_Studio_Project.zip');
    }
    if (fs.existsSync(prebuiltZipPublic)) {
      return res.download(prebuiltZipPublic, 'ALL_TOOLS_Android_Studio_Project.zip');
    }

    const zip = new JSZip();
    addDirectoryToZip(zip, __dirname, __dirname);
    const buffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="ALL_TOOLS_Android_Studio_Project.zip"');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err: any) {
    console.error('ZIP Export Error:', err);
    res.status(500).json({ error: err.message || 'Export failed' });
  }
};

app.get('/api/export-project-zip', sendProjectZip);
app.get('/api/download/android-project', sendProjectZip);
app.get('/ALL_TOOLS_Android_Studio_Project.zip', sendProjectZip);

// Applet configuration / health
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Dev server with Vite middleware vs Production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

app.listen(port, () => {
  console.log(`ALL TOOLS full-stack server running on port ${port}`);
});
