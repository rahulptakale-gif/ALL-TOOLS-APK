import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Heart, Clock, Settings } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, favorites, history, t } = useApp();

  const navItems = [
    {
      id: 'home' as const,
      label: t('home'),
      icon: Home,
    },
    {
      id: 'favorites' as const,
      label: t('favorites'),
      icon: Heart,
      badgeCount: favorites.length,
    },
    {
      id: 'history' as const,
      label: t('history'),
      icon: Clock,
      badgeCount: history.length > 0 ? history.length : undefined,
    },
    {
      id: 'settings' as const,
      label: t('settings'),
      icon: Settings,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#1A1B20]/95 backdrop-blur-md border-t border-orange-100 dark:border-neutral-800 pb-safe">
      <div className="max-w-[480px] mx-auto grid grid-cols-4 px-2 py-1.5">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-[#FF6B00] dark:text-[#FF8A00]'
                  : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200'
              }`}
            >
              <div className="relative">
                <div
                  className={`p-1 rounded-xl transition-all ${
                    isActive ? 'bg-orange-50 dark:bg-orange-950/50 scale-110' : ''
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 transition-transform ${
                      isActive ? 'stroke-[2.5px]' : 'stroke-[1.75px]'
                    }`}
                  />
                </div>
                {item.badgeCount !== undefined && item.badgeCount > 0 && (
                  <span className="absolute -top-1 -right-2 px-1.5 py-0.2 bg-[#FF6B00] text-white text-[9px] font-bold rounded-full border-2 border-white dark:border-[#1A1B20]">
                    {item.badgeCount > 99 ? '99+' : item.badgeCount}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] mt-0.5 tracking-tight transition-all font-medium ${
                  isActive ? 'font-bold' : ''
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
