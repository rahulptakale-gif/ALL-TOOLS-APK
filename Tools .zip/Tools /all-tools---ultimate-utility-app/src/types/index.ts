export type ToolCategory = 
  | 'pdf'
  | 'image'
  | 'converter'
  | 'csc'
  | 'qr'
  | 'calculator'
  | 'text';

export type Language = 'en' | 'hi' | 'mr';

export interface ToolItem {
  id: string;
  name: string;
  nameHi: string;
  nameMr: string;
  description: string;
  descriptionHi: string;
  descriptionMr: string;
  category: ToolCategory;
  iconName: string;
  badge?: string;
  isPopular?: boolean;
  isDaily?: boolean;
  isCSC?: boolean;
  requiresInternet?: boolean;
}

export interface HistoryItem {
  id: string;
  toolId: string;
  toolName: string;
  timestamp: number;
  fileName?: string;
  actionSummary: string;
}

export interface RecentProcessedFile {
  id: string;
  fileName: string;
  toolId: string;
  toolName: string;
  timestamp: number;
  actionSummary: string;
  sizeKb?: number;
  category?: ToolCategory;
}

export interface AppState {
  theme: 'light' | 'dark';
  language: Language;
  accentColor: string;
  favorites: string[];
  history: HistoryItem[];
  recentFiles: RecentProcessedFile[];
  activeTab: 'home' | 'favorites' | 'history' | 'settings';
  selectedCategory: ToolCategory | 'all';
  activeToolId: string | null;
  searchQuery: string;
}
