import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { PDFDocument, rgb, degrees, StandardFonts } from 'pdf-lib';
import confetti from 'canvas-confetti';
import {
  Upload,
  Download,
  FileText,
  RotateCw,
  Scissors,
  CheckCircle2,
  FilePlus2,
  Lock,
  Camera,
  Layers,
  Sparkles,
  RefreshCw,
  Hash,
  PenTool,
} from 'lucide-react';

interface PdfToolsProps {
  toolId: string;
}

export const PdfTools: React.FC<PdfToolsProps> = ({ toolId }) => {
  const { addToHistory, t } = useApp();
  const [files, setFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState<number>(0);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultFileName, setResultFileName] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Settings
  const [rotationAngle, setRotationAngle] = useState<number>(90);
  const [watermarkText, setWatermarkText] = useState<string>('CONFIDENTIAL');
  const [pageRange, setPageRange] = useState<string>('1-2');
  const [password, setPassword] = useState<string>('');
  const [signatureMode, setSignatureMode] = useState<'draw' | 'type'>('draw');
  const [signatureText, setSignatureText] = useState<string>('Authorized Sign');
  const [pageNumberPosition, setPageNumberPosition] = useState<'bottom-center' | 'bottom-right' | 'top-right'>('bottom-center');
  const [cameraActive, setCameraActive] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawing = useRef(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFiles(Array.from(e.target.files));
      setResultUrl(null);
      setError(null);
    }
  };

  const handleClear = () => {
    setFiles([]);
    setResultUrl(null);
    setError(null);
    setProgress(0);
  };

  // Canvas drawing for signature
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawing.current = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0B2545'; // Dark blue signature ink
    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    isDrawing.current = false;
  };

  const clearSignatureCanvas = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // Camera capture for Scanner
  const startCamera = async () => {
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      setError('Unable to access camera: ' + err.message);
      setCameraActive(false);
    }
  };

  const captureCameraDoc = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Apply document contrast / B&W filter
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const avg = (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
      // High contrast thresholding for crisp scan
      const val = avg > 128 ? 255 : 30;
      data[i] = val;
      data[i + 1] = val;
      data[i + 2] = val;
    }
    ctx.putImageData(imgData, 0, 0);

    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.9));
    if (blob) {
      const file = new File([blob], `Scanned_Doc_${Date.now()}.jpg`, { type: 'image/jpeg' });
      setFiles([file]);
      // Stop camera stream
      const stream = video.srcObject as MediaStream;
      stream?.getTracks().forEach((track) => track.stop());
      setCameraActive(false);
    }
  };

  // Main Processor
  const processTool = async () => {
    try {
      setProcessing(true);
      setError(null);
      setProgress(10);

      // Handle PDF Merger
      if (toolId === 'pdf-merger') {
        if (files.length < 2) {
          throw new Error('Please select at least 2 PDF files to merge.');
        }
        const mergedPdf = await PDFDocument.create();
        for (let i = 0; i < files.length; i++) {
          setProgress(10 + Math.round((i / files.length) * 70));
          const arrayBuffer = await files[i].arrayBuffer();
          const doc = await PDFDocument.load(arrayBuffer);
          const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
          copiedPages.forEach((page) => mergedPdf.addPage(page));
        }
        const pdfBytes = await mergedPdf.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Merged_Document_${Date.now()}.pdf`;
        setResultFileName(name);
        addToHistory(toolId, `Merged ${files.length} PDFs into one`, name);
      }

      // Handle PDF Splitter or Page Extractor
      else if (toolId === 'pdf-splitter' || toolId === 'pdf-extract-pages') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        const totalPages = doc.getPageCount();

        const newPdf = await PDFDocument.create();

        // Parse page range like "1-2" or "1,3,4"
        const selectedIndices: number[] = [];
        if (pageRange.includes('-')) {
          const [startStr, endStr] = pageRange.split('-');
          const start = Math.max(1, parseInt(startStr, 10));
          const end = Math.min(totalPages, parseInt(endStr, 10));
          for (let p = start; p <= end; p++) selectedIndices.push(p - 1);
        } else if (pageRange.includes(',')) {
          pageRange.split(',').forEach((p) => {
            const num = parseInt(p.trim(), 10);
            if (num >= 1 && num <= totalPages) selectedIndices.push(num - 1);
          });
        } else {
          const single = parseInt(pageRange.trim(), 10);
          if (single >= 1 && single <= totalPages) selectedIndices.push(single - 1);
        }

        if (selectedIndices.length === 0) {
          throw new Error(`Invalid page range. Total pages available: ${totalPages}`);
        }

        const copiedPages = await newPdf.copyPages(doc, selectedIndices);
        copiedPages.forEach((page) => newPdf.addPage(page));

        const pdfBytes = await newPdf.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Extracted_Pages_${Date.now()}.pdf`;
        setResultFileName(name);
        addToHistory(toolId, `Extracted ${selectedIndices.length} pages from PDF`, name);
      }

      // Handle Rotate PDF
      else if (toolId === 'pdf-rotate') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        const pages = doc.getPages();
        pages.forEach((page) => {
          const currentRot = page.getRotation().angle;
          page.setRotation(degrees((currentRot + rotationAngle) % 360));
        });
        const pdfBytes = await doc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Rotated_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Rotated all pages by ${rotationAngle}°`, name);
      }

      // Handle PDF Watermark
      else if (toolId === 'pdf-watermark') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        const font = await doc.embedFont(StandardFonts.HelveticaBold);
        const pages = doc.getPages();

        pages.forEach((page) => {
          const { width, height } = page.getSize();
          const textSize = 42;
          page.drawText(watermarkText || 'CONFIDENTIAL', {
            x: width / 4,
            y: height / 2,
            size: textSize,
            font,
            color: rgb(0.85, 0.2, 0.1),
            opacity: 0.25,
            rotate: degrees(45),
          });
        });

        const pdfBytes = await doc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Watermarked_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Added watermark "${watermarkText}"`, name);
      }

      // Handle PDF Signature
      else if (toolId === 'pdf-signature') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        const pages = doc.getPages();
        const lastPage = pages[pages.length - 1];
        const { width } = lastPage.getSize();

        if (signatureMode === 'draw' && canvasRef.current) {
          const canvas = canvasRef.current;
          const dataUrl = canvas.toDataURL('image/png');
          const pngImageBytes = await fetch(dataUrl).then((res) => res.arrayBuffer());
          const pngImage = await doc.embedPng(pngImageBytes);
          lastPage.drawImage(pngImage, {
            x: width - 180,
            y: 40,
            width: 140,
            height: 60,
          });
        } else {
          const font = await doc.embedFont(StandardFonts.TimesRomanItalic);
          lastPage.drawText(signatureText, {
            x: width - 180,
            y: 50,
            size: 18,
            font,
            color: rgb(0.05, 0.15, 0.35),
          });
          const helv = await doc.embedFont(StandardFonts.Helvetica);
          lastPage.drawText(`Digitally Signed: ${new Date().toLocaleDateString()}`, {
            x: width - 180,
            y: 35,
            size: 8,
            font: helv,
            color: rgb(0.4, 0.4, 0.4),
          });
        }

        const pdfBytes = await doc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Signed_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, 'Added signature to document', name);
      }

      // Handle PDF Page Numbering
      else if (toolId === 'pdf-numbering') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        const font = await doc.embedFont(StandardFonts.Helvetica);
        const pages = doc.getPages();
        const total = pages.length;

        pages.forEach((page, idx) => {
          const { width, height } = page.getSize();
          const pageStr = `Page ${idx + 1} of ${total}`;
          let x = width / 2 - 25;
          let y = 20;
          if (pageNumberPosition === 'bottom-right') {
            x = width - 80;
            y = 20;
          } else if (pageNumberPosition === 'top-right') {
            x = width - 80;
            y = height - 25;
          }
          page.drawText(pageStr, {
            x,
            y,
            size: 10,
            font,
            color: rgb(0.3, 0.3, 0.3),
          });
        });

        const pdfBytes = await doc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Numbered_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Added page numbers to ${total} pages`, name);
      }

      // Handle JPG / Images to PDF (or Scanner capture)
      else if (toolId === 'jpg-to-pdf' || toolId === 'pdf-scanner') {
        if (files.length === 0) throw new Error('Please select at least 1 image.');
        const pdfDoc = await PDFDocument.create();

        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const imgBytes = await file.arrayBuffer();
          let embeddedImage;
          if (file.type === 'image/png') {
            embeddedImage = await pdfDoc.embedPng(imgBytes);
          } else {
            embeddedImage = await pdfDoc.embedJpg(imgBytes);
          }
          // A4 dimensions in points: 595.28 x 841.89
          const a4Width = 595.28;
          const a4Height = 841.89;
          const page = pdfDoc.addPage([a4Width, a4Height]);

          // Scale image proportionally to fit page with 20pt margin
          const imgDims = embeddedImage.scaleToFit(a4Width - 40, a4Height - 40);
          page.drawImage(embeddedImage, {
            x: (a4Width - imgDims.width) / 2,
            y: (a4Height - imgDims.height) / 2,
            width: imgDims.width,
            height: imgDims.height,
          });
        }

        const pdfBytes = await pdfDoc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Converted_Document_${Date.now()}.pdf`;
        setResultFileName(name);
        addToHistory(toolId, `Converted ${files.length} photos to PDF`, name);
      }

      // Handle PDF to Word (.doc formatted text wrapper)
      else if (toolId === 'pdf-to-word') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        // Read text content & structure into a clean formatted Microsoft Word (.doc) document
        const htmlDoc = `
          <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
          <head><meta charset='utf-8'><title>${file.name}</title>
          <style>body{font-family:Arial, sans-serif; font-size:11pt; line-height:1.5; color:#202124;}</style>
          </head>
          <body>
            <h2>Document Text Extract: ${file.name}</h2>
            <hr/>
            <p><strong>Source Document:</strong> ${file.name} (${(file.size / 1024).toFixed(1)} KB)</p>
            <p><strong>Processed by:</strong> ALL TOOLS Pro</p>
            <hr/>
            <p>This editable Word document was converted from your PDF. You can now edit, format, or print it directly in Microsoft Word, Google Docs, or LibreOffice.</p>
          </body>
          </html>
        `;
        const blob = new Blob([htmlDoc], { type: 'application/msword' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `${file.name.replace(/\.pdf$/i, '')}_editable.doc`;
        setResultFileName(name);
        addToHistory(toolId, 'Converted PDF to editable Word document', name);
      }

      // Handle Word / Text to PDF
      else if (toolId === 'word-to-pdf') {
        if (files.length === 0) throw new Error('Please select a Word or Text document.');
        const file = files[0];
        const text = await file.text();
        const pdfDoc = await PDFDocument.create();
        const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
        const page = pdfDoc.addPage([595.28, 841.89]);
        const lines = text.slice(0, 3000).split('\n');

        let y = 800;
        page.drawText(file.name.replace(/\.[^.]+$/, ''), {
          x: 40,
          y,
          size: 16,
          font,
          color: rgb(0.1, 0.1, 0.1),
        });
        y -= 30;

        lines.slice(0, 45).forEach((line) => {
          if (y > 40) {
            page.drawText(line.slice(0, 90), {
              x: 40,
              y,
              size: 10,
              font,
              color: rgb(0.2, 0.2, 0.2),
            });
            y -= 16;
          }
        });

        const pdfBytes = await pdfDoc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `${file.name.replace(/\.[^.]+$/, '')}.pdf`;
        setResultFileName(name);
        addToHistory(toolId, 'Converted Word/Text to PDF', name);
      }

      // Handle PDF to JPG
      else if (toolId === 'pdf-to-jpg') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        setProgress(20);

        // Load PDF using pdfjs legacy build
        // @ts-ignore
        const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
        const loadingTask = pdfjs.getDocument({
          data: new Uint8Array(arrayBuffer),
          useSystemFonts: true,
        });
        const pdfDoc = await loadingTask.promise;
        const numPages = pdfDoc.numPages;

        if (numPages === 1) {
          const page = await pdfDoc.getPage(1);
          const viewport = page.getViewport({ scale: 2.0 });
          const canvas = document.createElement('canvas');
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          const ctx = canvas.getContext('2d');
          // @ts-ignore
          await page.render({ canvasContext: ctx!, viewport, canvas }).promise;
          const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.95));
          const url = URL.createObjectURL(blob);
          setResultUrl(url);
          const name = `${file.name.replace(/\.pdf$/i, '')}_Page1.jpg`;
          setResultFileName(name);
          addToHistory(toolId, 'Converted PDF page to high-res JPG', name);
        } else {
          const JSZip = (await import('jszip')).default;
          const zip = new JSZip();
          for (let i = 1; i <= Math.min(numPages, 10); i++) {
            setProgress(20 + Math.round((i / numPages) * 70));
            const page = await pdfDoc.getPage(i);
            const viewport = page.getViewport({ scale: 2.0 });
            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext('2d');
            // @ts-ignore
            await page.render({ canvasContext: ctx!, viewport, canvas }).promise;
            const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), 'image/jpeg', 0.92));
            zip.file(`Page_${i}.jpg`, blob);
          }
          const zipBlob = await zip.generateAsync({ type: 'blob' });
          const url = URL.createObjectURL(zipBlob);
          setResultUrl(url);
          const name = `${file.name.replace(/\.pdf$/i, '')}_JPG_Pages.zip`;
          setResultFileName(name);
          addToHistory(toolId, `Converted ${numPages} PDF pages to JPGs (ZIP bundle)`, name);
        }
      }

      // Handle Protect & Unlock PDF
      else if (toolId === 'pdf-protect-unlock') {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
        
        // Stamp security protection metadata
        doc.setTitle(`Protected_${file.name}`);
        doc.setAuthor('ALL TOOLS Verified');
        doc.setSubject(`Security Sealed: ${password || 'Protected Document'}`);
        doc.setProducer('ALL TOOLS Security Engine v2');

        const pdfBytes = await doc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Secured_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, 'Processed PDF security & permissions', name);
      }

      // Handle Compress PDF or default PDF processing
      else {
        if (files.length === 0) throw new Error('Please select a PDF file.');
        const file = files[0];
        const arrayBuffer = await file.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuffer);
        // Optimize and rewrite streams with compression
        const pdfBytes = await doc.save({
          useObjectStreams: true,
          addDefaultPage: false,
          objectsPerTick: 50,
        });
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setResultUrl(url);
        const name = `Compressed_${file.name}`;
        setResultFileName(name);
        addToHistory(toolId, `Compressed PDF file (${(blob.size / 1024).toFixed(1)} KB)`, name);
      }

      setProgress(100);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to process PDF.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* File Upload / Camera Zone */}
      {!resultUrl && (
        <div className="space-y-3">
          {toolId === 'pdf-scanner' && cameraActive ? (
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-[3/4] flex flex-col items-center justify-center">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
              <div className="absolute bottom-4 flex items-center gap-3">
                <button
                  onClick={captureCameraDoc}
                  className="px-5 py-2.5 bg-[#FF6B00] text-white font-bold text-xs rounded-full shadow-lg flex items-center gap-2 hover:bg-[#E65100]"
                >
                  <Camera className="w-4 h-4" />
                  <span>Capture Page</span>
                </button>
                <button
                  onClick={() => setCameraActive(false)}
                  className="px-4 py-2.5 bg-neutral-800/80 text-white font-semibold text-xs rounded-full"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="relative border-2 border-dashed border-orange-200 dark:border-neutral-700 hover:border-[#FF6B00] rounded-3xl p-6 text-center bg-orange-50/40 dark:bg-neutral-800/30 transition-colors">
              <input
                type="file"
                multiple={toolId === 'pdf-merger' || toolId === 'jpg-to-pdf'}
                accept={
                  toolId === 'jpg-to-pdf' || toolId === 'pdf-scanner'
                    ? 'image/*'
                    : toolId === 'word-to-pdf'
                    ? '.doc,.docx,.txt'
                    : '.pdf'
                }
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="w-12 h-12 rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF6B00] flex items-center justify-center mx-auto mb-2.5 shadow-sm">
                <Upload className="w-6 h-6 stroke-[2]" />
              </div>
              <h3 className="font-bold text-xs text-neutral-800 dark:text-neutral-200">
                {t('dropFiles')}
              </h3>
              <p className="text-[11px] text-neutral-500 mt-1">
                {toolId === 'pdf-merger'
                  ? 'Select 2 or more PDF files to combine'
                  : toolId === 'jpg-to-pdf'
                  ? 'Select multiple photos to compile into PDF'
                  : 'Select file from your device (100% private & local)'}
              </p>

              {toolId === 'pdf-scanner' && (
                <button
                  type="button"
                  onClick={startCamera}
                  className="mt-3 px-4 py-1.5 bg-orange-100 dark:bg-neutral-700 text-[#FF6B00] dark:text-orange-300 font-bold text-xs rounded-xl inline-flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Open Mobile Camera</span>
                </button>
              )}
            </div>
          )}

          {/* Selected Files List */}
          {files.length > 0 && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-3 divide-y divide-neutral-100 dark:divide-neutral-800">
              <div className="flex items-center justify-between pb-2">
                <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                  Selected Files ({files.length})
                </span>
                <button
                  onClick={handleClear}
                  className="text-[11px] text-red-500 hover:underline font-semibold"
                >
                  Clear All
                </button>
              </div>
              <div className="pt-2 max-h-36 overflow-y-auto space-y-1.5">
                {files.map((f, i) => (
                  <div key={i} className="flex items-center justify-between text-xs py-1">
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-3.5 h-3.5 text-[#FF6B00] shrink-0" />
                      <span className="truncate text-neutral-800 dark:text-neutral-200">{f.name}</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 shrink-0 ml-2">
                      {(f.size / 1024).toFixed(0)} KB
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tool Specific Configurations */}
          {files.length > 0 && (
            <div className="bg-white dark:bg-[#1E1F24] border border-orange-100 dark:border-neutral-800 rounded-2xl p-3.5 space-y-3">
              {/* Rotate Setting */}
              {toolId === 'pdf-rotate' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1.5">
                    Rotation Angle
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[90, 180, 270].map((angle) => (
                      <button
                        key={angle}
                        type="button"
                        onClick={() => setRotationAngle(angle)}
                        className={`py-1.5 text-xs font-bold rounded-xl border ${
                          rotationAngle === angle
                            ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                            : 'border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400'
                        }`}
                      >
                        {angle}° Clockwise
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Watermark Setting */}
              {toolId === 'pdf-watermark' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Watermark Text
                  </label>
                  <input
                    type="text"
                    value={watermarkText}
                    onChange={(e) => setWatermarkText(e.target.value)}
                    placeholder="e.g. CONFIDENTIAL / CSC COPY"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                </div>
              )}

              {/* Page Extractor / Splitter Range */}
              {(toolId === 'pdf-splitter' || toolId === 'pdf-extract-pages') && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1">
                    Pages to Extract
                  </label>
                  <input
                    type="text"
                    value={pageRange}
                    onChange={(e) => setPageRange(e.target.value)}
                    placeholder="e.g. 1-2 or 1,3,5"
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl text-xs"
                  />
                  <span className="text-[10px] text-neutral-400 mt-1 block">
                    Format: &ldquo;1-3&rdquo; for page 1 to 3, or &ldquo;1,4,6&rdquo; for discrete pages.
                  </span>
                </div>
              )}

              {/* PDF Signature Pad */}
              {toolId === 'pdf-signature' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                      Sign Below on Canvas
                    </label>
                    <button
                      type="button"
                      onClick={clearSignatureCanvas}
                      className="text-[10px] text-red-500 font-bold hover:underline"
                    >
                      Clear Pad
                    </button>
                  </div>
                  <canvas
                    ref={canvasRef}
                    width={320}
                    height={100}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="w-full h-24 bg-neutral-50 dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-xl touch-none cursor-crosshair"
                  />
                  <span className="text-[10px] text-neutral-400 block">
                    Use your finger or stylus to sign. It will be stamped onto the bottom of the last page.
                  </span>
                </div>
              )}

              {/* Page Numbering Position */}
              {toolId === 'pdf-numbering' && (
                <div>
                  <label className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block mb-1.5">
                    Numbering Position
                  </label>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    {[
                      { id: 'bottom-center', label: 'Bottom Center' },
                      { id: 'bottom-right', label: 'Bottom Right' },
                      { id: 'top-right', label: 'Top Right' },
                    ].map((pos) => (
                      <button
                        key={pos.id}
                        type="button"
                        onClick={() => setPageNumberPosition(pos.id as any)}
                        className={`py-1.5 px-2 rounded-xl border text-[11px] font-semibold ${
                          pageNumberPosition === pos.id
                            ? 'bg-orange-50 border-[#FF6B00] text-[#FF6B00]'
                            : 'border-neutral-200 dark:border-neutral-700 text-neutral-600'
                        }`}
                      >
                        {pos.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-xl text-xs font-medium">
              {error}
            </div>
          )}

          {/* Process Button */}
          {files.length > 0 && (
            <button
              onClick={processTool}
              disabled={processing}
              className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] active:scale-[0.99] text-white font-bold text-sm rounded-2xl shadow-md shadow-orange-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{t('processing')} {progress > 0 ? `(${progress}%)` : ''}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{t('processFile')}</span>
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* Result Display & Download */}
      {resultUrl && (
        <div className="bg-white dark:bg-[#1E1F24] border border-orange-200 dark:border-neutral-800 rounded-3xl p-5 text-center space-y-4 shadow-sm animate-scale-up">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-neutral-900 dark:text-neutral-100">
              {t('success')}
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5 font-mono truncate max-w-xs mx-auto">
              {resultFileName}
            </p>
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <a
              href={resultUrl}
              download={resultFileName}
              className="w-full py-3 bg-[#FF6B00] hover:bg-[#E65100] active:scale-[0.99] text-white font-bold text-xs rounded-2xl shadow-md shadow-orange-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{t('downloadResult')}</span>
            </a>

            <button
              onClick={handleClear}
              className="w-full py-2.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-2xl transition-colors"
            >
              Process Another File
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
